import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Play, ChevronRight } from "lucide-react"
import Link from "next/link"

export default function DemoPage() {
  return (
    <div className="min-h-screen flex flex-col bg-navy">
      <Navbar />
      <main className="flex-1">
        <section className="py-16 md:py-24">
          <div className="container px-4 md:px-6">
            <div className="text-center space-y-4 mb-12">
              <h1 className="text-3xl md:text-4xl font-bold text-white glow-text">See Eternal Echo in Action</h1>
              <p className="text-xl text-blue-200 max-w-3xl mx-auto">
                Watch how our AI-powered platform preserves your voice, personality, and memories for future
                generations.
              </p>
            </div>

            <div className="max-w-4xl mx-auto bg-navy-dark border border-blue-900/50 rounded-xl overflow-hidden shadow-2xl">
              <div className="aspect-video relative bg-navy-light flex items-center justify-center">
                <img
                  src="/placeholder.svg?height=540&width=960"
                  alt="Demo video thumbnail"
                  className="w-full h-full object-cover opacity-60"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <Button
                    size="lg"
                    className="rounded-full w-16 h-16 bg-blue-600 hover:bg-blue-700 hover:scale-105 transition-transform"
                  >
                    <Play className="h-8 w-8 text-white" />
                  </Button>
                </div>
              </div>
              <div className="p-6">
                <h2 className="text-xl font-semibold text-white mb-2">Eternal Echo: Preserving Your Digital Legacy</h2>
                <p className="text-blue-200">
                  This demo showcases how our AI technology creates an interactive digital version of you that can
                  communicate with future generations.
                </p>
              </div>
            </div>

            <div className="mt-16 grid md:grid-cols-3 gap-8">
              <div className="bg-navy-dark border border-blue-900/50 rounded-lg p-6 text-center">
                <div className="w-12 h-12 rounded-full bg-blue-900/30 flex items-center justify-center mx-auto mb-4">
                  <span className="text-blue-400 text-xl font-bold">1</span>
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">AI Persona Creation</h3>
                <p className="text-blue-200">
                  See how our system learns your speech patterns, personality traits, and memories.
                </p>
              </div>

              <div className="bg-navy-dark border border-blue-900/50 rounded-lg p-6 text-center">
                <div className="w-12 h-12 rounded-full bg-blue-900/30 flex items-center justify-center mx-auto mb-4">
                  <span className="text-blue-400 text-xl font-bold">2</span>
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">Voice & Video Generation</h3>
                <p className="text-blue-200">
                  Watch our AI generate new speech and video content that looks and sounds just like you.
                </p>
              </div>

              <div className="bg-navy-dark border border-blue-900/50 rounded-lg p-6 text-center">
                <div className="w-12 h-12 rounded-full bg-blue-900/30 flex items-center justify-center mx-auto mb-4">
                  <span className="text-blue-400 text-xl font-bold">3</span>
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">Interactive Experience</h3>
                <p className="text-blue-200">
                  Experience how your loved ones can interact with your digital legacy in the future.
                </p>
              </div>
            </div>

            <div className="mt-16 text-center">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700" asChild>
                <Link href="/signup">
                  Get Started <ChevronRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}

