import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"

export default function SignupPage() {
  return (
    <div className="min-h-screen flex flex-col bg-navy">
      <Navbar />
      <div className="flex-1 flex items-center justify-center px-4 py-12">
        <div className="w-full max-w-md space-y-8">
          <div className="text-center">
            <h1 className="text-3xl font-bold text-white">Create your account</h1>
            <p className="mt-2 text-blue-200">Start preserving your digital legacy today</p>
          </div>

          <div className="bg-navy-dark border border-blue-900/50 p-6 rounded-lg shadow-xl space-y-6">
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="first-name" className="text-blue-100">
                    First name
                  </Label>
                  <Input id="first-name" className="bg-navy-light border-blue-900/50 text-blue-100" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="last-name" className="text-blue-100">
                    Last name
                  </Label>
                  <Input id="last-name" className="bg-navy-light border-blue-900/50 text-blue-100" />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="email" className="text-blue-100">
                  Email
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your@email.com"
                  className="bg-navy-light border-blue-900/50 text-blue-100"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-blue-100">
                  Password
                </Label>
                <Input id="password" type="password" className="bg-navy-light border-blue-900/50 text-blue-100" />
                <p className="text-xs text-blue-300">Password must be at least 8 characters long</p>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox id="terms" />
                <Label htmlFor="terms" className="text-sm text-blue-200">
                  I agree to the{" "}
                  <Link href="/terms" className="text-blue-400 hover:text-blue-300">
                    Terms of Service
                  </Link>{" "}
                  and{" "}
                  <Link href="/privacy" className="text-blue-400 hover:text-blue-300">
                    Privacy Policy
                  </Link>
                </Label>
              </div>
            </div>

            <Button className="w-full bg-blue-600 hover:bg-blue-700">Create account</Button>

            <div className="text-center text-sm text-blue-200">
              Already have an account?{" "}
              <Link href="/login" className="text-blue-400 hover:text-blue-300">
                Sign in
              </Link>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  )
}

