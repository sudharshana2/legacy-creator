import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar, Mic, Video, MessageSquare, Users, Clock } from "lucide-react"
import { Switch } from "@/components/ui/switch"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

export default function CreateMessagePage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-white">Create Message</h1>
        <p className="text-blue-200">Schedule a message to be delivered to your loved ones in the future.</p>
      </div>

      <Tabs defaultValue="scheduled" className="space-y-4">
        <TabsList className="bg-navy-dark border border-blue-900/50">
          <TabsTrigger value="scheduled" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            <Calendar className="h-4 w-4 mr-2" />
            Scheduled Message
          </TabsTrigger>
          <TabsTrigger value="on-demand" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            <MessageSquare className="h-4 w-4 mr-2" />
            On-Demand Message
          </TabsTrigger>
        </TabsList>
        <TabsContent value="scheduled" className="space-y-4">
          <Card className="bg-navy-dark border-blue-900/50">
            <CardHeader>
              <CardTitle className="text-white">Create Scheduled Message</CardTitle>
              <CardDescription className="text-blue-300">
                This message will be delivered on a specific date in the future
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="message-title" className="text-blue-100">
                  Message Title
                </Label>
                <Input
                  id="message-title"
                  placeholder="E.g., 'Birthday Wishes' or 'Anniversary Message'"
                  className="bg-navy-light border-blue-900/50 text-blue-100"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="delivery-date" className="text-blue-100">
                    Delivery Date
                  </Label>
                  <div className="flex items-center space-x-2">
                    <Calendar className="h-4 w-4 text-blue-400" />
                    <Input id="delivery-date" type="date" className="bg-navy-light border-blue-900/50 text-blue-100" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="delivery-time" className="text-blue-100">
                    Delivery Time (Optional)
                  </Label>
                  <div className="flex items-center space-x-2">
                    <Clock className="h-4 w-4 text-blue-400" />
                    <Input id="delivery-time" type="time" className="bg-navy-light border-blue-900/50 text-blue-100" />
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="recipients" className="text-blue-100">
                  Recipients
                </Label>
                <div className="flex items-center space-x-2">
                  <Users className="h-4 w-4 text-blue-400" />
                  <Select>
                    <SelectTrigger className="bg-navy-light border-blue-900/50 text-blue-100">
                      <SelectValue placeholder="Select recipients" />
                    </SelectTrigger>
                    <SelectContent className="bg-navy-dark border-blue-900/50">
                      <SelectItem value="all">All Connections</SelectItem>
                      <SelectItem value="family">Family Members</SelectItem>
                      <SelectItem value="emma">Emma Johnson</SelectItem>
                      <SelectItem value="michael">Michael Johnson</SelectItem>
                      <SelectItem value="sarah">Sarah Williams</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <p className="text-xs text-blue-300">Select who should receive this message on the delivery date</p>
              </div>

              <div className="space-y-2">
                <Label className="text-blue-100">Message Type</Label>
                <RadioGroup defaultValue="text" className="grid grid-cols-1 md:grid-cols-3 gap-2">
                  <div className="flex items-center space-x-2 rounded-lg border border-blue-900/50 p-3 bg-navy-light">
                    <RadioGroupItem value="text" id="text" className="text-blue-400" />
                    <Label htmlFor="text" className="flex items-center text-blue-100">
                      <MessageSquare className="h-4 w-4 mr-2 text-blue-400" />
                      Text Message
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2 rounded-lg border border-blue-900/50 p-3 bg-navy-light">
                    <RadioGroupItem value="audio" id="audio" className="text-blue-400" />
                    <Label htmlFor="audio" className="flex items-center text-blue-100">
                      <Mic className="h-4 w-4 mr-2 text-blue-400" />
                      Voice Message
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2 rounded-lg border border-blue-900/50 p-3 bg-navy-light">
                    <RadioGroupItem value="video" id="video" className="text-blue-400" />
                    <Label htmlFor="video" className="flex items-center text-blue-100">
                      <Video className="h-4 w-4 mr-2 text-blue-400" />
                      Video Message
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="space-y-2">
                <Label htmlFor="message-content" className="text-blue-100">
                  Message Content
                </Label>
                <Textarea
                  id="message-content"
                  placeholder="Write your message here..."
                  className="min-h-[200px] bg-navy-light border-blue-900/50 text-blue-100"
                />
                <p className="text-xs text-blue-300">
                  For voice or video messages, this text will be used as the script
                </p>
              </div>

              <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light space-y-3">
                <h3 className="text-sm font-medium text-white">Additional Options</h3>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="send-email" className="text-blue-100">
                      Send Email Notification
                    </Label>
                    <p className="text-xs text-blue-300">Notify recipients by email when the message is available</p>
                  </div>
                  <Switch id="send-email" defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="allow-reply" className="text-blue-100">
                      Allow Replies
                    </Label>
                    <p className="text-xs text-blue-300">Let recipients leave responses to your message</p>
                  </div>
                  <Switch id="allow-reply" defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="private-message" className="text-blue-100">
                      Private Message
                    </Label>
                    <p className="text-xs text-blue-300">Only visible to selected recipients</p>
                  </div>
                  <Switch id="private-message" defaultChecked />
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col space-y-2">
              <Button className="w-full bg-blue-600 hover:bg-blue-700">Schedule Message</Button>
              <Button variant="outline" className="w-full border-blue-900/50 text-blue-100">
                Save as Draft
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        <TabsContent value="on-demand" className="space-y-4">
          <Card className="bg-navy-dark border-blue-900/50">
            <CardHeader>
              <CardTitle className="text-white">Create On-Demand Message</CardTitle>
              <CardDescription className="text-blue-300">
                This message will be available for your connections to access anytime
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="message-title-ondemand" className="text-blue-100">
                  Message Title
                </Label>
                <Input
                  id="message-title-ondemand"
                  placeholder="E.g., 'Life Advice' or 'Family History'"
                  className="bg-navy-light border-blue-900/50 text-blue-100"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="message-category" className="text-blue-100">
                  Category
                </Label>
                <Select>
                  <SelectTrigger className="bg-navy-light border-blue-900/50 text-blue-100">
                    <SelectValue placeholder="Select a category" />
                  </SelectTrigger>
                  <SelectContent className="bg-navy-dark border-blue-900/50">
                    <SelectItem value="advice">Life Advice</SelectItem>
                    <SelectItem value="history">Family History</SelectItem>
                    <SelectItem value="stories">Personal Stories</SelectItem>
                    <SelectItem value="values">Values & Beliefs</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="recipients-ondemand" className="text-blue-100">
                  Who Can Access
                </Label>
                <div className="flex items-center space-x-2">
                  <Users className="h-4 w-4 text-blue-400" />
                  <Select>
                    <SelectTrigger className="bg-navy-light border-blue-900/50 text-blue-100">
                      <SelectValue placeholder="Select who can access" />
                    </SelectTrigger>
                    <SelectContent className="bg-navy-dark border-blue-900/50">
                      <SelectItem value="all">All Connections</SelectItem>
                      <SelectItem value="family">Family Members Only</SelectItem>
                      <SelectItem value="specific">Specific People</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-blue-100">Message Type</Label>
                <RadioGroup defaultValue="text" className="grid grid-cols-1 md:grid-cols-3 gap-2">
                  <div className="flex items-center space-x-2 rounded-lg border border-blue-900/50 p-3 bg-navy-light">
                    <RadioGroupItem value="text" id="text-ondemand" className="text-blue-400" />
                    <Label htmlFor="text-ondemand" className="flex items-center text-blue-100">
                      <MessageSquare className="h-4 w-4 mr-2 text-blue-400" />
                      Text Message
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2 rounded-lg border border-blue-900/50 p-3 bg-navy-light">
                    <RadioGroupItem value="audio" id="audio-ondemand" className="text-blue-400" />
                    <Label htmlFor="audio-ondemand" className="flex items-center text-blue-100">
                      <Mic className="h-4 w-4 mr-2 text-blue-400" />
                      Voice Message
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2 rounded-lg border border-blue-900/50 p-3 bg-navy-light">
                    <RadioGroupItem value="video" id="video-ondemand" className="text-blue-400" />
                    <Label htmlFor="video-ondemand" className="flex items-center text-blue-100">
                      <Video className="h-4 w-4 mr-2 text-blue-400" />
                      Video Message
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="space-y-2">
                <Label htmlFor="message-content-ondemand" className="text-blue-100">
                  Message Content
                </Label>
                <Textarea
                  id="message-content-ondemand"
                  placeholder="Write your message here..."
                  className="min-h-[200px] bg-navy-light border-blue-900/50 text-blue-100"
                />
              </div>

              <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light space-y-3">
                <h3 className="text-sm font-medium text-white">Access Settings</h3>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="ai-answer" className="text-blue-100">
                      AI Can Answer Questions
                    </Label>
                    <p className="text-xs text-blue-300">Allow your AI to use this content to answer questions</p>
                  </div>
                  <Switch id="ai-answer" defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="allow-reply-ondemand" className="text-blue-100">
                      Allow Replies
                    </Label>
                    <p className="text-xs text-blue-300">Let recipients leave responses to your message</p>
                  </div>
                  <Switch id="allow-reply-ondemand" defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="notify-access" className="text-blue-100">
                      Notify on Access
                    </Label>
                    <p className="text-xs text-blue-300">Receive notifications when someone views this message</p>
                  </div>
                  <Switch id="notify-access" />
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col space-y-2">
              <Button className="w-full bg-blue-600 hover:bg-blue-700">Create On-Demand Message</Button>
              <Button variant="outline" className="w-full border-blue-900/50 text-blue-100">
                Save as Draft
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

