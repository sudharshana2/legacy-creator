import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, Plus, Search, Clock, Mail } from "lucide-react"
import Link from "next/link"
import { Input } from "@/components/ui/input"

export default function MessagesPage() {
  const messages = [
    {
      id: "1",
      title: "Birthday Message for Emma",
      recipient: "Emma Johnson",
      date: "May 15, 2026",
      description: "A special message for your daughter's 18th birthday with advice for adulthood.",
      status: "scheduled",
    },
    {
      id: "2",
      title: "Wedding Anniversary",
      recipient: "Sarah Williams",
      date: "July 8, 2025",
      description: "A loving message for your spouse on your 15th wedding anniversary.",
      status: "scheduled",
    },
    {
      id: "3",
      title: "Graduation Congratulations",
      recipient: "Michael Johnson",
      date: "June 10, 2024",
      description: "Congratulatory message for your son's college graduation.",
      status: "scheduled",
    },
    {
      id: "4",
      title: "Life Advice",
      recipient: "All Family Members",
      date: "On Request",
      description: "General life advice that can be accessed anytime by your family members.",
      status: "on-demand",
    },
    {
      id: "5",
      title: "Family History",
      recipient: "All Descendants",
      date: "On Request",
      description: "Stories about your family history and ancestry for future generations.",
      status: "on-demand",
    },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-white">Future Messages</h1>
          <p className="text-blue-200">Schedule messages to be delivered to your loved ones in the future.</p>
        </div>
        <Button className="bg-blue-600 hover:bg-blue-700" asChild>
          <Link href="/dashboard/messages/new">
            <Plus className="mr-2 h-4 w-4" /> Create Message
          </Link>
        </Button>
      </div>

      <div className="flex items-center space-x-2">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-blue-400" />
          <Input placeholder="Search messages..." className="pl-8 bg-navy-dark border-blue-900/50 text-blue-100" />
        </div>
        <Button variant="outline" className="border-blue-900/50 text-blue-100">
          Filter
        </Button>
      </div>

      <Tabs defaultValue="all" className="space-y-4">
        <TabsList className="bg-navy-dark border border-blue-900/50">
          <TabsTrigger value="all" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            All
          </TabsTrigger>
          <TabsTrigger value="scheduled" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            Scheduled
          </TabsTrigger>
          <TabsTrigger value="on-demand" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            On-Demand
          </TabsTrigger>
        </TabsList>
        <TabsContent value="all" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {messages.map((message) => (
              <Card key={message.id} className="bg-navy-dark border-blue-900/50">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-white">{message.title}</CardTitle>
                      <CardDescription className="text-blue-300">For: {message.recipient}</CardDescription>
                    </div>
                    <div className="bg-blue-900/30 px-2 py-1 rounded text-xs text-blue-200">
                      {message.status === "scheduled" ? "Scheduled" : "On-Demand"}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center text-sm text-blue-200 mb-2">
                    <Clock className="mr-2 h-4 w-4 text-blue-400" />
                    {message.status === "scheduled" ? `Delivery: ${message.date}` : "Available on request"}
                  </div>
                  <p className="text-sm text-blue-200">{message.description}</p>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="outline" size="sm" className="border-blue-900/50 text-blue-100">
                    Edit
                  </Button>
                  <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                    Preview
                  </Button>
                </CardFooter>
              </Card>
            ))}
            <Card className="border-dashed border-2 flex flex-col items-center justify-center p-6 h-full bg-transparent border-blue-900/50">
              <Calendar className="h-10 w-10 text-blue-400 mb-2" />
              <p className="text-blue-200 text-center mb-4">Schedule a new message</p>
              <Button className="bg-blue-600 hover:bg-blue-700" asChild>
                <Link href="/dashboard/messages/new">Create Message</Link>
              </Button>
            </Card>
          </div>
        </TabsContent>
        <TabsContent value="scheduled" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {messages
              .filter((m) => m.status === "scheduled")
              .map((message) => (
                <Card key={message.id} className="bg-navy-dark border-blue-900/50">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-white">{message.title}</CardTitle>
                        <CardDescription className="text-blue-300">For: {message.recipient}</CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center text-sm text-blue-200 mb-2">
                      <Clock className="mr-2 h-4 w-4 text-blue-400" />
                      Delivery: {message.date}
                    </div>
                    <p className="text-sm text-blue-200">{message.description}</p>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" size="sm" className="border-blue-900/50 text-blue-100">
                      Edit
                    </Button>
                    <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                      Preview
                    </Button>
                  </CardFooter>
                </Card>
              ))}
          </div>
        </TabsContent>
        <TabsContent value="on-demand" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {messages
              .filter((m) => m.status === "on-demand")
              .map((message) => (
                <Card key={message.id} className="bg-navy-dark border-blue-900/50">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-white">{message.title}</CardTitle>
                        <CardDescription className="text-blue-300">For: {message.recipient}</CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center text-sm text-blue-200 mb-2">
                      <Mail className="mr-2 h-4 w-4 text-blue-400" />
                      Available on request
                    </div>
                    <p className="text-sm text-blue-200">{message.description}</p>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" size="sm" className="border-blue-900/50 text-blue-100">
                      Edit
                    </Button>
                    <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                      Preview
                    </Button>
                  </CardFooter>
                </Card>
              ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

