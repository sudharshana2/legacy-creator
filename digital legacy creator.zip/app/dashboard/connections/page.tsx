import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { Search, UserPlus, Mail, Clock } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"

export default function ConnectionsPage() {
  const connections = [
    {
      id: "1",
      name: "Emma Johnson",
      relationship: "Daughter",
      status: "active",
      lastAccess: "2 days ago",
      avatar: "EJ",
      image: "/placeholder.svg?height=100&width=100",
    },
    {
      id: "2",
      name: "Michael Johnson",
      relationship: "Son",
      status: "active",
      lastAccess: "1 week ago",
      avatar: "MJ",
      image: "/placeholder.svg?height=100&width=100",
    },
    {
      id: "3",
      name: "Sarah Williams",
      relationship: "Sister",
      status: "active",
      lastAccess: "3 days ago",
      avatar: "SW",
      image: "/placeholder.svg?height=100&width=100",
    },
    {
      id: "4",
      name: "Robert Chen",
      relationship: "Friend",
      status: "pending",
      lastAccess: "Never",
      avatar: "RC",
      image: "/placeholder.svg?height=100&width=100",
    },
    {
      id: "5",
      name: "Jennifer Lopez",
      relationship: "Friend",
      status: "pending",
      lastAccess: "Never",
      avatar: "JL",
      image: "/placeholder.svg?height=100&width=100",
    },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-white">Connections</h1>
          <p className="text-blue-200">Manage who can access your digital legacy.</p>
        </div>
        <Button className="bg-blue-600 hover:bg-blue-700 text-white" asChild>
          <Link href="/dashboard/connections/invite">
            <UserPlus className="mr-2 h-4 w-4" /> Invite Connection
          </Link>
        </Button>
      </div>

      <div className="flex items-center space-x-2">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-blue-400" />
          <Input placeholder="Search connections..." className="pl-8 bg-navy-dark border-blue-900/50 text-blue-100" />
        </div>
        <Button variant="outline" className="border-blue-900/50 text-blue-100">
          Filter
        </Button>
      </div>

      <Tabs defaultValue="active" className="space-y-4">
        <TabsList className="bg-navy-dark border border-blue-900/50">
          <TabsTrigger value="active" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            Active
          </TabsTrigger>
          <TabsTrigger value="pending" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            Pending
          </TabsTrigger>
          <TabsTrigger value="all" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            All
          </TabsTrigger>
        </TabsList>
        <TabsContent value="active" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {connections
              .filter((c) => c.status === "active")
              .map((connection) => (
                <Card key={connection.id} className="bg-navy-dark border-blue-900/50">
                  <CardHeader className="flex flex-row items-center gap-4 pb-2">
                    <Avatar className="h-14 w-14">
                      <AvatarImage src={connection.image} alt={connection.name} />
                      <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-500 text-white">
                        {connection.avatar}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <CardTitle className="text-white">{connection.name}</CardTitle>
                      <CardDescription className="text-blue-300">{connection.relationship}</CardDescription>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center text-sm text-blue-200 mb-2">
                      <Clock className="mr-2 h-4 w-4 text-blue-400" />
                      Last access: {connection.lastAccess}
                    </div>
                    <div className="flex items-center text-sm text-blue-200">
                      <Mail className="mr-2 h-4 w-4 text-blue-400" />
                      Messages: 12
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" size="sm" className="border-blue-900/50 text-blue-100">
                      Manage Access
                    </Button>
                    <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                      Message
                    </Button>
                  </CardFooter>
                </Card>
              ))}
          </div>
        </TabsContent>
        <TabsContent value="pending" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {connections
              .filter((c) => c.status === "pending")
              .map((connection) => (
                <Card key={connection.id} className="bg-navy-dark border-blue-900/50">
                  <CardHeader className="flex flex-row items-center gap-4 pb-2">
                    <Avatar className="h-14 w-14">
                      <AvatarImage src={connection.image} alt={connection.name} />
                      <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-500 text-white">
                        {connection.avatar}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <CardTitle className="text-white">{connection.name}</CardTitle>
                      <CardDescription className="text-blue-300">{connection.relationship}</CardDescription>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center text-sm text-blue-200 mb-2">
                      <Clock className="mr-2 h-4 w-4 text-blue-400" />
                      Invitation sent: 3 days ago
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" size="sm" className="border-blue-900/50 text-blue-100">
                      Cancel
                    </Button>
                    <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                      Resend
                    </Button>
                  </CardFooter>
                </Card>
              ))}
          </div>
        </TabsContent>
        <TabsContent value="all" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {connections.map((connection) => (
              <Card key={connection.id} className="bg-navy-dark border-blue-900/50">
                <CardHeader className="flex flex-row items-center gap-4 pb-2">
                  <Avatar className="h-14 w-14">
                    <AvatarImage src={connection.image} alt={connection.name} />
                    <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-500 text-white">
                      {connection.avatar}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <CardTitle className="text-white">{connection.name}</CardTitle>
                    <CardDescription className="text-blue-300">{connection.relationship}</CardDescription>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center text-sm text-blue-200 mb-2">
                    <Clock className="mr-2 h-4 w-4 text-blue-400" />
                    {connection.status === "active" ? `Last access: ${connection.lastAccess}` : "Pending invitation"}
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="outline" size="sm" className="border-blue-900/50 text-blue-100">
                    {connection.status === "active" ? "Manage" : "Cancel"}
                  </Button>
                  <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                    {connection.status === "active" ? "Message" : "Resend"}
                  </Button>
                </CardFooter>
              </Card>
            ))}
            <Card className="border-dashed border-2 flex flex-col items-center justify-center p-6 h-full bg-transparent border-blue-900/50">
              <UserPlus className="h-10 w-10 text-blue-400 mb-2" />
              <p className="text-blue-200 text-center mb-4">Invite a new connection</p>
              <Button className="bg-blue-600 hover:bg-blue-700 text-white" asChild>
                <Link href="/dashboard/connections/invite">Add Connection</Link>
              </Button>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

