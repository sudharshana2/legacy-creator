import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Mail, Users, LinkIcon, Copy, Check } from "lucide-react"
import { Switch } from "@/components/ui/switch"

export default function InviteConnectionPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-white">Invite Connections</h1>
        <p className="text-blue-200">Invite family and friends to connect with your digital legacy.</p>
      </div>

      <Tabs defaultValue="email" className="space-y-4">
        <TabsList className="bg-navy-dark border border-blue-900/50">
          <TabsTrigger value="email" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            <Mail className="h-4 w-4 mr-2" />
            Email Invite
          </TabsTrigger>
          <TabsTrigger value="bulk" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            <Users className="h-4 w-4 mr-2" />
            Bulk Invite
          </TabsTrigger>
          <TabsTrigger value="link" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            <LinkIcon className="h-4 w-4 mr-2" />
            Invite Link
          </TabsTrigger>
        </TabsList>
        <TabsContent value="email" className="space-y-4">
          <Card className="bg-navy-dark border-blue-900/50">
            <CardHeader>
              <CardTitle className="text-white">Send Email Invitation</CardTitle>
              <CardDescription className="text-blue-300">
                Invite someone to connect with your digital legacy via email
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="recipient-name" className="text-blue-100">
                    Recipient's Name
                  </Label>
                  <Input
                    id="recipient-name"
                    placeholder="Enter name"
                    className="bg-navy-light border-blue-900/50 text-blue-100"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="recipient-email" className="text-blue-100">
                    Recipient's Email
                  </Label>
                  <Input
                    id="recipient-email"
                    type="email"
                    placeholder="Enter email"
                    className="bg-navy-light border-blue-900/50 text-blue-100"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="relationship" className="text-blue-100">
                  Relationship
                </Label>
                <Select>
                  <SelectTrigger className="bg-navy-light border-blue-900/50 text-blue-100">
                    <SelectValue placeholder="Select relationship" />
                  </SelectTrigger>
                  <SelectContent className="bg-navy-dark border-blue-900/50">
                    <SelectItem value="family">Family Member</SelectItem>
                    <SelectItem value="friend">Friend</SelectItem>
                    <SelectItem value="spouse">Spouse/Partner</SelectItem>
                    <SelectItem value="child">Child</SelectItem>
                    <SelectItem value="parent">Parent</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="message" className="text-blue-100">
                  Personal Message (Optional)
                </Label>
                <Textarea
                  id="message"
                  placeholder="Add a personal message to your invitation"
                  className="min-h-[100px] bg-navy-light border-blue-900/50 text-blue-100"
                />
              </div>

              <div className="space-y-4 rounded-lg border border-blue-900/50 p-4 bg-navy-light">
                <h3 className="text-sm font-medium text-white">Access Permissions</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="view-memories" className="text-blue-100">
                        View Memories
                      </Label>
                      <p className="text-xs text-blue-300">Allow access to your memory collection</p>
                    </div>
                    <Switch id="view-memories" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="interact-ai" className="text-blue-100">
                        Interact with AI Persona
                      </Label>
                      <p className="text-xs text-blue-300">Allow conversations with your AI persona</p>
                    </div>
                    <Switch id="interact-ai" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="future-messages" className="text-blue-100">
                        Receive Future Messages
                      </Label>
                      <p className="text-xs text-blue-300">Receive scheduled messages from you</p>
                    </div>
                    <Switch id="future-messages" defaultChecked />
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col space-y-2">
              <Button className="w-full bg-blue-600 hover:bg-blue-700">Send Invitation</Button>
            </CardFooter>
          </Card>
        </TabsContent>
        <TabsContent value="bulk" className="space-y-4">
          <Card className="bg-navy-dark border-blue-900/50">
            <CardHeader>
              <CardTitle className="text-white">Bulk Invite Connections</CardTitle>
              <CardDescription className="text-blue-300">
                Invite multiple people at once to connect with your digital legacy
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light">
                <h3 className="text-sm font-medium text-white mb-2">Instructions</h3>
                <ul className="space-y-1 text-sm text-blue-200">
                  <li>• Enter one email address per line</li>
                  <li>• Optionally include names using the format: Name &lt;email@example.com&gt;</li>
                  <li>• You can invite up to 20 people at once</li>
                </ul>
              </div>

              <div className="space-y-2">
                <Label htmlFor="bulk-emails" className="text-blue-100">
                  Email Addresses
                </Label>
                <Textarea
                  id="bulk-emails"
                  placeholder="John Smith <john@example.com>
Mary Johnson <mary@example.com>
david@example.com"
                  className="min-h-[150px] bg-navy-light border-blue-900/50 text-blue-100"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="relationship-bulk" className="text-blue-100">
                  Relationship (Applied to all)
                </Label>
                <Select>
                  <SelectTrigger className="bg-navy-light border-blue-900/50 text-blue-100">
                    <SelectValue placeholder="Select relationship" />
                  </SelectTrigger>
                  <SelectContent className="bg-navy-dark border-blue-900/50">
                    <SelectItem value="family">Family Member</SelectItem>
                    <SelectItem value="friend">Friend</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="message-bulk" className="text-blue-100">
                  Personal Message (Optional)
                </Label>
                <Textarea
                  id="message-bulk"
                  placeholder="Add a personal message to your invitations"
                  className="min-h-[100px] bg-navy-light border-blue-900/50 text-blue-100"
                />
              </div>

              <div className="space-y-4 rounded-lg border border-blue-900/50 p-4 bg-navy-light">
                <h3 className="text-sm font-medium text-white">Default Access Permissions</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="view-memories-bulk" className="text-blue-100">
                        View Memories
                      </Label>
                      <p className="text-xs text-blue-300">Allow access to your memory collection</p>
                    </div>
                    <Switch id="view-memories-bulk" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="interact-ai-bulk" className="text-blue-100">
                        Interact with AI Persona
                      </Label>
                      <p className="text-xs text-blue-300">Allow conversations with your AI persona</p>
                    </div>
                    <Switch id="interact-ai-bulk" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="future-messages-bulk" className="text-blue-100">
                        Receive Future Messages
                      </Label>
                      <p className="text-xs text-blue-300">Receive scheduled messages from you</p>
                    </div>
                    <Switch id="future-messages-bulk" defaultChecked />
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full bg-blue-600 hover:bg-blue-700">Send Bulk Invitations</Button>
            </CardFooter>
          </Card>
        </TabsContent>
        <TabsContent value="link" className="space-y-4">
          <Card className="bg-navy-dark border-blue-900/50">
            <CardHeader>
              <CardTitle className="text-white">Create Invite Link</CardTitle>
              <CardDescription className="text-blue-300">
                Generate a link that you can share with others to connect with your digital legacy
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light">
                <h3 className="text-sm font-medium text-white mb-2">About Invite Links</h3>
                <p className="text-sm text-blue-200">
                  Invite links allow anyone with the link to request connection to your digital legacy. You'll still
                  need to approve each connection request.
                </p>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="link-expiration" className="text-blue-100">
                    Link Expiration
                  </Label>
                  <Select>
                    <SelectTrigger className="bg-navy-light border-blue-900/50 text-blue-100">
                      <SelectValue placeholder="Select expiration time" />
                    </SelectTrigger>
                    <SelectContent className="bg-navy-dark border-blue-900/50">
                      <SelectItem value="never">Never expires</SelectItem>
                      <SelectItem value="24h">24 hours</SelectItem>
                      <SelectItem value="7d">7 days</SelectItem>
                      <SelectItem value="30d">30 days</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="max-uses" className="text-blue-100">
                    Maximum Uses
                  </Label>
                  <Select>
                    <SelectTrigger className="bg-navy-light border-blue-900/50 text-blue-100">
                      <SelectValue placeholder="Select maximum uses" />
                    </SelectTrigger>
                    <SelectContent className="bg-navy-dark border-blue-900/50">
                      <SelectItem value="unlimited">Unlimited</SelectItem>
                      <SelectItem value="1">1 use only</SelectItem>
                      <SelectItem value="5">5 uses</SelectItem>
                      <SelectItem value="10">10 uses</SelectItem>
                      <SelectItem value="25">25 uses</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-4 rounded-lg border border-blue-900/50 p-4 bg-navy-light">
                <h3 className="text-sm font-medium text-white">Default Access Permissions</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="view-memories-link" className="text-blue-100">
                        View Memories
                      </Label>
                      <p className="text-xs text-blue-300">Allow access to your memory collection</p>
                    </div>
                    <Switch id="view-memories-link" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="interact-ai-link" className="text-blue-100">
                        Interact with AI Persona
                      </Label>
                      <p className="text-xs text-blue-300">Allow conversations with your AI persona</p>
                    </div>
                    <Switch id="interact-ai-link" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="future-messages-link" className="text-blue-100">
                        Receive Future Messages
                      </Label>
                      <p className="text-xs text-blue-300">Receive scheduled messages from you</p>
                    </div>
                    <Switch id="future-messages-link" defaultChecked />
                  </div>
                </div>
              </div>

              <Button className="w-full bg-blue-600 hover:bg-blue-700">Generate Invite Link</Button>

              <div className="rounded-lg border border-blue-900/50 p-4 bg-navy">
                <h3 className="text-sm font-medium text-white mb-2">Your Invite Link</h3>
                <div className="flex items-center space-x-2">
                  <Input
                    value="https://eternalecho.com/invite/abc123xyz"
                    readOnly
                    className="bg-navy-light border-blue-900/50 text-blue-100"
                  />
                  <Button variant="outline" size="icon" className="border-blue-900/50 text-blue-100">
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
                <div className="flex items-center mt-2 text-xs text-blue-300">
                  <Check className="h-3 w-3 mr-1 text-green-500" />
                  Active - Never expires, Unlimited uses
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

