import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Mic, Play, SkipForward, Volume2, AudioWaveformIcon as Waveform, Upload, Clock } from "lucide-react"
import { Slider } from "@/components/ui/slider"

export default function VoiceTrainingPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-white">Voice Training</h1>
        <p className="text-blue-200">Train your AI to speak with your voice by recording voice samples.</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="bg-navy-dark border-blue-900/50">
          <CardHeader>
            <CardTitle className="text-white">Voice Model Status</CardTitle>
            <CardDescription className="text-blue-300">Your voice model is 40% complete</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-blue-100">Training Progress</span>
                <span className="font-medium text-blue-100">40%</span>
              </div>
              <Progress value={40} className="h-2" />
            </div>

            <div className="grid grid-cols-2 gap-4 mt-4">
              <div className="bg-navy-light rounded-lg p-4 border border-blue-900/30">
                <h3 className="text-sm font-medium text-white mb-1">Recorded</h3>
                <div className="flex items-baseline">
                  <span className="text-2xl font-bold text-blue-100">12</span>
                  <span className="text-sm text-blue-300 ml-1">minutes</span>
                </div>
              </div>
              <div className="bg-navy-light rounded-lg p-4 border border-blue-900/30">
                <h3 className="text-sm font-medium text-white mb-1">Recommended</h3>
                <div className="flex items-baseline">
                  <span className="text-2xl font-bold text-blue-100">30</span>
                  <span className="text-sm text-blue-300 ml-1">minutes</span>
                </div>
              </div>
            </div>

            <div className="bg-navy-light rounded-lg p-4 border border-blue-900/30">
              <h3 className="text-sm font-medium text-white mb-2">Voice Quality Assessment</h3>
              <div className="grid grid-cols-3 gap-2 text-center">
                <div>
                  <div className="text-xs text-blue-300 mb-1">Clarity</div>
                  <div className="text-sm font-medium text-blue-100">Good</div>
                </div>
                <div>
                  <div className="text-xs text-blue-300 mb-1">Consistency</div>
                  <div className="text-sm font-medium text-blue-100">Fair</div>
                </div>
                <div>
                  <div className="text-xs text-blue-300 mb-1">Naturalness</div>
                  <div className="text-sm font-medium text-blue-100">Good</div>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button className="w-full bg-blue-600 hover:bg-blue-700">Test Your Voice Model</Button>
          </CardFooter>
        </Card>

        <Card className="bg-navy-dark border-blue-900/50">
          <CardHeader>
            <CardTitle className="text-white">Voice Sample Preview</CardTitle>
            <CardDescription className="text-blue-300">Listen to your AI voice model</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex flex-col items-center justify-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-blue-900/30 flex items-center justify-center">
                <Volume2 className="h-8 w-8 text-blue-400" />
              </div>
              <div className="text-center">
                <h3 className="text-lg font-medium text-white">Your AI Voice</h3>
                <p className="text-sm text-blue-200">Based on 12 minutes of recordings</p>
              </div>
            </div>

            <div className="space-y-2">
              <div className="h-12 bg-navy-light rounded-lg overflow-hidden relative">
                <div className="absolute inset-0 flex items-center justify-center">
                  <Waveform className="h-6 w-full text-blue-500/50" />
                </div>
                <div className="absolute left-0 top-0 bottom-0 w-1/3 bg-blue-500/10 border-r border-blue-500"></div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-blue-300">0:12</span>
                <span className="text-xs text-blue-300">0:35</span>
              </div>
            </div>

            <div className="flex items-center justify-center space-x-4">
              <Button variant="outline" size="icon" className="rounded-full h-10 w-10 border-blue-900/50 text-blue-100">
                <SkipForward className="h-4 w-4 rotate-180" />
              </Button>
              <Button size="icon" className="rounded-full h-12 w-12 bg-blue-600 hover:bg-blue-700">
                <Play className="h-5 w-5" />
              </Button>
              <Button variant="outline" size="icon" className="rounded-full h-10 w-10 border-blue-900/50 text-blue-100">
                <SkipForward className="h-4 w-4" />
              </Button>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-blue-100">Volume</span>
                <Volume2 className="h-4 w-4 text-blue-400" />
              </div>
              <Slider defaultValue={[75]} max={100} step={1} className="w-full" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="record" className="space-y-4">
        <TabsList className="bg-navy-dark border border-blue-900/50">
          <TabsTrigger value="record" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            Record Voice
          </TabsTrigger>
          <TabsTrigger value="upload" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            Upload Recordings
          </TabsTrigger>
          <TabsTrigger value="scripts" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            Recording Scripts
          </TabsTrigger>
        </TabsList>
        <TabsContent value="record" className="space-y-4">
          <Card className="bg-navy-dark border-blue-900/50">
            <CardHeader>
              <CardTitle className="text-white">Record Your Voice</CardTitle>
              <CardDescription className="text-blue-300">
                Read the provided script to train your AI voice model
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light">
                <h3 className="font-medium text-white mb-2">Recording Guidelines</h3>
                <ul className="space-y-1 text-sm text-blue-200">
                  <li>• Find a quiet environment with minimal background noise</li>
                  <li>• Speak naturally at your normal pace and tone</li>
                  <li>• Read the entire script without long pauses</li>
                  <li>• Try to maintain consistent volume and distance from microphone</li>
                </ul>
              </div>

              <div className="space-y-2">
                <h3 className="text-sm font-medium text-white">Recording Script</h3>
                <div className="rounded-lg border border-blue-900/50 p-4 bg-navy">
                  <p className="text-blue-100">
                    The quick brown fox jumps over the lazy dog. I believe that every person has unique gifts to share
                    with the world. My favorite memory from childhood was when we would visit the lake house in summer.
                    The sunset over the mountains creates the most beautiful palette of colors. I've always thought that
                    kindness is the most important quality in a person.
                  </p>
                </div>
              </div>

              <div className="flex flex-col items-center justify-center space-y-4 p-6 border border-blue-900/50 rounded-lg">
                <div className="w-16 h-16 rounded-full bg-blue-900/30 flex items-center justify-center">
                  <Mic className="h-8 w-8 text-blue-400" />
                </div>
                <Button className="bg-blue-600 hover:bg-blue-700">Start Recording</Button>
                <p className="text-xs text-blue-200 text-center">
                  Click to start recording. You'll need to grant microphone permissions.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="upload" className="space-y-4">
          <Card className="bg-navy-dark border-blue-900/50">
            <CardHeader>
              <CardTitle className="text-white">Upload Voice Recordings</CardTitle>
              <CardDescription className="text-blue-300">
                Upload existing audio files to train your AI voice model
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light">
                <h3 className="font-medium text-white mb-2">Upload Guidelines</h3>
                <ul className="space-y-1 text-sm text-blue-200">
                  <li>• Upload clear audio with minimal background noise</li>
                  <li>• Supported formats: MP3, WAV, M4A</li>
                  <li>• Maximum file size: 50MB per file</li>
                  <li>• Longer recordings provide better training results</li>
                </ul>
              </div>

              <div className="flex flex-col items-center justify-center space-y-4 p-8 border-2 border-dashed border-blue-900/50 rounded-lg">
                <Upload className="h-10 w-10 text-blue-400" />
                <div className="text-center">
                  <h3 className="text-white font-medium">Drag & Drop Files</h3>
                  <p className="text-sm text-blue-200 mt-1">or click to browse your files</p>
                </div>
                <Button variant="outline" className="border-blue-900/50 text-blue-100">
                  Select Files
                </Button>
              </div>

              <div className="space-y-2">
                <h3 className="text-sm font-medium text-white">Uploaded Files</h3>
                <div className="rounded-lg border border-blue-900/50 p-4 bg-navy">
                  <div className="text-center text-blue-200 py-2">No files uploaded yet</div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full bg-blue-600 hover:bg-blue-700" disabled>
                Process Uploads
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        <TabsContent value="scripts" className="space-y-4">
          <Card className="bg-navy-dark border-blue-900/50">
            <CardHeader>
              <CardTitle className="text-white">Recording Scripts</CardTitle>
              <CardDescription className="text-blue-300">
                Choose from various scripts to record for better voice training
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-white font-medium">Basic Script</h3>
                    <div className="bg-blue-900/30 px-2 py-1 rounded text-xs text-blue-200">1 minute</div>
                  </div>
                  <p className="text-sm text-blue-200 mb-3">
                    A short script with common phrases and phonetic diversity.
                  </p>
                  <Button variant="outline" size="sm" className="w-full border-blue-900/50 text-blue-100">
                    Use This Script
                  </Button>
                </div>

                <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-white font-medium">Emotional Range</h3>
                    <div className="bg-blue-900/30 px-2 py-1 rounded text-xs text-blue-200">3 minutes</div>
                  </div>
                  <p className="text-sm text-blue-200 mb-3">
                    Sentences with various emotional tones to capture your expression.
                  </p>
                  <Button variant="outline" size="sm" className="w-full border-blue-900/50 text-blue-100">
                    Use This Script
                  </Button>
                </div>

                <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-white font-medium">Storytelling</h3>
                    <div className="bg-blue-900/30 px-2 py-1 rounded text-xs text-blue-200">5 minutes</div>
                  </div>
                  <p className="text-sm text-blue-200 mb-3">
                    A short story to capture your natural storytelling voice.
                  </p>
                  <Button variant="outline" size="sm" className="w-full border-blue-900/50 text-blue-100">
                    Use This Script
                  </Button>
                </div>

                <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-white font-medium">Technical Terms</h3>
                    <div className="bg-blue-900/30 px-2 py-1 rounded text-xs text-blue-200">4 minutes</div>
                  </div>
                  <p className="text-sm text-blue-200 mb-3">
                    Uncommon words and technical terms to improve pronunciation.
                  </p>
                  <Button variant="outline" size="sm" className="w-full border-blue-900/50 text-blue-100">
                    Use This Script
                  </Button>
                </div>
              </div>

              <div className="rounded-lg border border-blue-900/50 p-4 bg-navy">
                <h3 className="text-white font-medium mb-2">Custom Script</h3>
                <p className="text-sm text-blue-200 mb-4">
                  Create your own script with content that's meaningful to you. Personal stories, advice, or messages to
                  loved ones make excellent training material.
                </p>
                <Button variant="outline" className="w-full border-blue-900/50 text-blue-100">
                  Create Custom Script
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Card className="bg-navy-dark border-blue-900/50">
        <CardHeader>
          <CardTitle className="text-white">Recording History</CardTitle>
          <CardDescription className="text-blue-300">Your previous voice recording sessions</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-white font-medium">Basic Script Recording</h3>
                  <p className="text-sm text-blue-200 mt-1">1:23 minutes</p>
                </div>
                <div className="flex items-center text-xs text-blue-300">
                  <Clock className="h-3 w-3 mr-1" />2 days ago
                </div>
              </div>
              <div className="flex items-center justify-between mt-3">
                <Button variant="outline" size="sm" className="border-blue-900/50 text-blue-100">
                  <Play className="h-3 w-3 mr-1" /> Play
                </Button>
                <Button variant="outline" size="sm" className="border-blue-900/50 text-blue-100">
                  Delete
                </Button>
              </div>
            </div>

            <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-white font-medium">Emotional Range Script</h3>
                  <p className="text-sm text-blue-200 mt-1">2:47 minutes</p>
                </div>
                <div className="flex items-center text-xs text-blue-300">
                  <Clock className="h-3 w-3 mr-1" />5 days ago
                </div>
              </div>
              <div className="flex items-center justify-between mt-3">
                <Button variant="outline" size="sm" className="border-blue-900/50 text-blue-100">
                  <Play className="h-3 w-3 mr-1" /> Play
                </Button>
                <Button variant="outline" size="sm" className="border-blue-900/50 text-blue-100">
                  Delete
                </Button>
              </div>
            </div>

            <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-white font-medium">Custom Recording</h3>
                  <p className="text-sm text-blue-200 mt-1">4:12 minutes</p>
                </div>
                <div className="flex items-center text-xs text-blue-300">
                  <Clock className="h-3 w-3 mr-1" />1 week ago
                </div>
              </div>
              <div className="flex items-center justify-between mt-3">
                <Button variant="outline" size="sm" className="border-blue-900/50 text-blue-100">
                  <Play className="h-3 w-3 mr-1" /> Play
                </Button>
                <Button variant="outline" size="sm" className="border-blue-900/50 text-blue-100">
                  Delete
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

