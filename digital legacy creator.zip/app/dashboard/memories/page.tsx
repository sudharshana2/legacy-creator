import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MessageSquare, Video, Image, FileText, Plus, Search } from "lucide-react"
import Link from "next/link"
import { Input } from "@/components/ui/input"

export default function MemoriesPage() {
  const memories = [
    {
      id: "1",
      title: "College Graduation Speech",
      type: "video",
      date: "May 15, 2022",
      description: "Your inspirational speech about perseverance and following your dreams.",
      icon: <Video className="h-10 w-10 text-blue-400" />,
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: "2",
      title: "Life Advice Collection",
      type: "text",
      date: "June 3, 2022",
      description: "A collection of your best advice on relationships, career, and happiness.",
      icon: <MessageSquare className="h-10 w-10 text-blue-400" />,
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: "3",
      title: "Family Vacation Photos",
      type: "image",
      date: "July 20, 2022",
      description: "Photos from our trip to Hawaii with the whole family.",
      icon: <Image className="h-10 w-10 text-blue-400" />,
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: "4",
      title: "My Life Story",
      type: "document",
      date: "August 12, 2022",
      description: "A comprehensive document detailing your life journey and major milestones.",
      icon: <FileText className="h-10 w-10 text-blue-400" />,
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: "5",
      title: "Wedding Day",
      type: "video",
      date: "September 5, 2022",
      description: "Video compilation of your wedding day with personal commentary.",
      icon: <Video className="h-10 w-10 text-blue-400" />,
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: "6",
      title: "Letters to My Children",
      type: "text",
      date: "October 10, 2022",
      description: "A series of heartfelt letters written to your children for different life stages.",
      icon: <MessageSquare className="h-10 w-10 text-blue-400" />,
      image: "/placeholder.svg?height=200&width=300",
    },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-white">Memories</h1>
          <p className="text-blue-200">Manage and organize your personal memories and stories.</p>
        </div>
        <Button className="bg-blue-600 hover:bg-blue-700" asChild>
          <Link href="/dashboard/memories/new">
            <Plus className="mr-2 h-4 w-4" /> Add Memory
          </Link>
        </Button>
      </div>

      <div className="flex items-center space-x-2">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-blue-400" />
          <Input placeholder="Search memories..." className="pl-8 bg-navy-dark border-blue-900/50 text-blue-100" />
        </div>
        <Button variant="outline" className="border-blue-900/50 text-blue-100">
          Filter
        </Button>
      </div>

      <Tabs defaultValue="all" className="space-y-4">
        <TabsList className="bg-navy-dark border border-blue-900/50">
          <TabsTrigger value="all" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            All
          </TabsTrigger>
          <TabsTrigger value="videos" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            Videos
          </TabsTrigger>
          <TabsTrigger value="text" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            Text
          </TabsTrigger>
          <TabsTrigger value="images" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            Images
          </TabsTrigger>
          <TabsTrigger value="documents" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            Documents
          </TabsTrigger>
        </TabsList>
        <TabsContent value="all" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {memories.map((memory) => (
              <Card key={memory.id} className="overflow-hidden bg-navy-dark border-blue-900/50">
                <div className="aspect-video bg-navy-light relative">
                  <img
                    src={memory.image || "/placeholder.svg"}
                    alt={memory.title}
                    className="w-full h-full object-cover opacity-60"
                  />
                  <div className="absolute inset-0 flex items-center justify-center">{memory.icon}</div>
                </div>
                <CardHeader>
                  <CardTitle className="text-white">{memory.title}</CardTitle>
                  <CardDescription className="text-blue-300">Added {memory.date}</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-blue-200">{memory.description}</p>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="outline" size="sm" className="border-blue-900/50 text-blue-100">
                    Edit
                  </Button>
                  <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                    View
                  </Button>
                </CardFooter>
              </Card>
            ))}
            <Card className="border-dashed border-2 flex flex-col items-center justify-center p-6 h-full bg-transparent border-blue-900/50">
              <Plus className="h-10 w-10 text-blue-400 mb-2" />
              <p className="text-blue-200 text-center mb-4">Add a new memory</p>
              <Button className="bg-blue-600 hover:bg-blue-700" asChild>
                <Link href="/dashboard/memories/new">Upload Memory</Link>
              </Button>
            </Card>
          </div>
        </TabsContent>
        <TabsContent value="videos" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {memories
              .filter((m) => m.type === "video")
              .map((memory) => (
                <Card key={memory.id} className="overflow-hidden bg-navy-dark border-blue-900/50">
                  <div className="aspect-video bg-navy-light relative">
                    <img
                      src={memory.image || "/placeholder.svg"}
                      alt={memory.title}
                      className="w-full h-full object-cover opacity-60"
                    />
                    <div className="absolute inset-0 flex items-center justify-center">{memory.icon}</div>
                  </div>
                  <CardHeader>
                    <CardTitle className="text-white">{memory.title}</CardTitle>
                    <CardDescription className="text-blue-300">Added {memory.date}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-blue-200">{memory.description}</p>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" size="sm" className="border-blue-900/50 text-blue-100">
                      Edit
                    </Button>
                    <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                      View
                    </Button>
                  </CardFooter>
                </Card>
              ))}
          </div>
        </TabsContent>
        {/* Similar content for other tabs */}
      </Tabs>
    </div>
  )
}

