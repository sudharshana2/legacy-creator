import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { MessageSquare, Image, Video, FileText, Upload, Calendar, MapPin, Tag, Users } from "lucide-react"
import { Switch } from "@/components/ui/switch"

export default function CreateMemoryPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-white">Create Memory</h1>
        <p className="text-blue-200">Add a new memory to your digital legacy collection.</p>
      </div>

      <Tabs defaultValue="text" className="space-y-4">
        <TabsList className="bg-navy-dark border border-blue-900/50">
          <TabsTrigger value="text" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            <MessageSquare className="h-4 w-4 mr-2" />
            Text Memory
          </TabsTrigger>
          <TabsTrigger value="image" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            <Image className="h-4 w-4 mr-2" />
            Photo Memory
          </TabsTrigger>
          <TabsTrigger value="video" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            <Video className="h-4 w-4 mr-2" />
            Video Memory
          </TabsTrigger>
          <TabsTrigger value="document" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            <FileText className="h-4 w-4 mr-2" />
            Document
          </TabsTrigger>
        </TabsList>
        <TabsContent value="text" className="space-y-4">
          <Card className="bg-navy-dark border-blue-900/50">
            <CardHeader>
              <CardTitle className="text-white">Create Text Memory</CardTitle>
              <CardDescription className="text-blue-300">
                Share a story, life lesson, or personal reflection
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="memory-title" className="text-blue-100">
                  Memory Title
                </Label>
                <Input
                  id="memory-title"
                  placeholder="E.g., 'My First Job' or 'Life Lessons I've Learned'"
                  className="bg-navy-light border-blue-900/50 text-blue-100"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="memory-date" className="text-blue-100">
                    When did this happen?
                  </Label>
                  <div className="flex items-center space-x-2">
                    <Calendar className="h-4 w-4 text-blue-400" />
                    <Input id="memory-date" type="date" className="bg-navy-light border-blue-900/50 text-blue-100" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="memory-location" className="text-blue-100">
                    Location (Optional)
                  </Label>
                  <div className="flex items-center space-x-2">
                    <MapPin className="h-4 w-4 text-blue-400" />
                    <Input
                      id="memory-location"
                      placeholder="E.g., 'New York' or 'Family Home'"
                      className="bg-navy-light border-blue-900/50 text-blue-100"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="memory-content" className="text-blue-100">
                  Memory Details
                </Label>
                <Textarea
                  id="memory-content"
                  placeholder="Describe this memory in detail, including how you felt, who was there, and why it's important to you..."
                  className="min-h-[200px] bg-navy-light border-blue-900/50 text-blue-100"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="memory-category" className="text-blue-100">
                  Category
                </Label>
                <div className="flex items-center space-x-2">
                  <Tag className="h-4 w-4 text-blue-400" />
                  <Select>
                    <SelectTrigger className="bg-navy-light border-blue-900/50 text-blue-100">
                      <SelectValue placeholder="Select a category" />
                    </SelectTrigger>
                    <SelectContent className="bg-navy-dark border-blue-900/50">
                      <SelectItem value="childhood">Childhood</SelectItem>
                      <SelectItem value="family">Family</SelectItem>
                      <SelectItem value="career">Career</SelectItem>
                      <SelectItem value="travel">Travel</SelectItem>
                      <SelectItem value="lessons">Life Lessons</SelectItem>
                      <SelectItem value="milestones">Milestones</SelectItem>
                      <SelectItem value="relationships">Relationships</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="memory-tags" className="text-blue-100">
                  Tags (Optional)
                </Label>
                <Input
                  id="memory-tags"
                  placeholder="E.g., family, advice, childhood (separate with commas)"
                  className="bg-navy-light border-blue-900/50 text-blue-100"
                />
              </div>

              <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light space-y-3">
                <h3 className="text-sm font-medium text-white">Privacy Settings</h3>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="ai-training" className="text-blue-100">
                      Use for AI Training
                    </Label>
                    <p className="text-xs text-blue-300">Allow your AI persona to learn from this memory</p>
                  </div>
                  <Switch id="ai-training" defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="visible-connections" className="text-blue-100">
                      Visible to Connections
                    </Label>
                    <p className="text-xs text-blue-300">Allow your connections to view this memory</p>
                  </div>
                  <Switch id="visible-connections" defaultChecked />
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col space-y-2">
              <Button className="w-full bg-blue-600 hover:bg-blue-700">Save Memory</Button>
              <Button variant="outline" className="w-full border-blue-900/50 text-blue-100">
                Save as Draft
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        <TabsContent value="image" className="space-y-4">
          <Card className="bg-navy-dark border-blue-900/50">
            <CardHeader>
              <CardTitle className="text-white">Create Photo Memory</CardTitle>
              <CardDescription className="text-blue-300">
                Upload photos with descriptions to preserve visual memories
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="photo-title" className="text-blue-100">
                  Memory Title
                </Label>
                <Input
                  id="photo-title"
                  placeholder="E.g., 'Family Vacation 2022' or 'Wedding Day'"
                  className="bg-navy-light border-blue-900/50 text-blue-100"
                />
              </div>

              <div className="flex flex-col items-center justify-center space-y-4 p-8 border-2 border-dashed border-blue-900/50 rounded-lg">
                <Upload className="h-10 w-10 text-blue-400" />
                <div className="text-center">
                  <h3 className="text-white font-medium">Drag & Drop Photos</h3>
                  <p className="text-sm text-blue-200 mt-1">or click to browse your files</p>
                </div>
                <Button variant="outline" className="border-blue-900/50 text-blue-100">
                  Select Photos
                </Button>
                <p className="text-xs text-blue-300">Supported formats: JPG, PNG, HEIC, WEBP (Max 20MB per file)</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="photo-date" className="text-blue-100">
                    When were these taken?
                  </Label>
                  <div className="flex items-center space-x-2">
                    <Calendar className="h-4 w-4 text-blue-400" />
                    <Input id="photo-date" type="date" className="bg-navy-light border-blue-900/50 text-blue-100" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="photo-location" className="text-blue-100">
                    Location (Optional)
                  </Label>
                  <div className="flex items-center space-x-2">
                    <MapPin className="h-4 w-4 text-blue-400" />
                    <Input
                      id="photo-location"
                      placeholder="E.g., 'Hawaii' or 'Grandma's House'"
                      className="bg-navy-light border-blue-900/50 text-blue-100"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="photo-description" className="text-blue-100">
                  Description
                </Label>
                <Textarea
                  id="photo-description"
                  placeholder="Describe these photos, who's in them, and why they're meaningful to you..."
                  className="min-h-[150px] bg-navy-light border-blue-900/50 text-blue-100"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="photo-people" className="text-blue-100">
                  People in Photos (Optional)
                </Label>
                <div className="flex items-center space-x-2">
                  <Users className="h-4 w-4 text-blue-400" />
                  <Input
                    id="photo-people"
                    placeholder="E.g., 'Emma, Michael, Mom, Dad'"
                    className="bg-navy-light border-blue-900/50 text-blue-100"
                  />
                </div>
              </div>

              <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light space-y-3">
                <h3 className="text-sm font-medium text-white">Privacy Settings</h3>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="ai-training-photo" className="text-blue-100">
                      Use for AI Training
                    </Label>
                    <p className="text-xs text-blue-300">Allow your AI persona to learn from these photos</p>
                  </div>
                  <Switch id="ai-training-photo" defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="visible-connections-photo" className="text-blue-100">
                      Visible to Connections
                    </Label>
                    <p className="text-xs text-blue-300">Allow your connections to view these photos</p>
                  </div>
                  <Switch id="visible-connections-photo" defaultChecked />
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full bg-blue-600 hover:bg-blue-700">Save Photo Memory</Button>
            </CardFooter>
          </Card>
        </TabsContent>
        <TabsContent value="video" className="space-y-4">
          <Card className="bg-navy-dark border-blue-900/50">
            <CardHeader>
              <CardTitle className="text-white">Create Video Memory</CardTitle>
              <CardDescription className="text-blue-300">
                Upload video footage to preserve dynamic memories
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="video-title" className="text-blue-100">
                  Memory Title
                </Label>
                <Input
                  id="video-title"
                  placeholder="E.g., 'Birthday Celebration' or 'Graduation Speech'"
                  className="bg-navy-light border-blue-900/50 text-blue-100"
                />
              </div>

              <div className="flex flex-col items-center justify-center space-y-4 p-8 border-2 border-dashed border-blue-900/50 rounded-lg">
                <Video className="h-10 w-10 text-blue-400" />
                <div className="text-center">
                  <h3 className="text-white font-medium">Drag & Drop Video</h3>
                  <p className="text-sm text-blue-200 mt-1">or click to browse your files</p>
                </div>
                <Button variant="outline" className="border-blue-900/50 text-blue-100">
                  Select Video
                </Button>
                <p className="text-xs text-blue-300">Supported formats: MP4, MOV, AVI (Max 500MB per file)</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="video-date" className="text-blue-100">
                    When was this recorded?
                  </Label>
                  <div className="flex items-center space-x-2">
                    <Calendar className="h-4 w-4 text-blue-400" />
                    <Input id="video-date" type="date" className="bg-navy-light border-blue-900/50 text-blue-100" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="video-location" className="text-blue-100">
                    Location (Optional)
                  </Label>
                  <div className="flex items-center space-x-2">
                    <MapPin className="h-4 w-4 text-blue-400" />
                    <Input
                      id="video-location"
                      placeholder="E.g., 'Home' or 'Central Park'"
                      className="bg-navy-light border-blue-900/50 text-blue-100"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="video-description" className="text-blue-100">
                  Description
                </Label>
                <Textarea
                  id="video-description"
                  placeholder="Describe what's happening in this video and why it's meaningful to you..."
                  className="min-h-[150px] bg-navy-light border-blue-900/50 text-blue-100"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="video-people" className="text-blue-100">
                  People in Video (Optional)
                </Label>
                <div className="flex items-center space-x-2">
                  <Users className="h-4 w-4 text-blue-400" />
                  <Input
                    id="video-people"
                    placeholder="E.g., 'Emma, Michael, Mom, Dad'"
                    className="bg-navy-light border-blue-900/50 text-blue-100"
                  />
                </div>
              </div>

              <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light space-y-3">
                <h3 className="text-sm font-medium text-white">Privacy Settings</h3>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="ai-training-video" className="text-blue-100">
                      Use for AI Training
                    </Label>
                    <p className="text-xs text-blue-300">Allow your AI persona to learn from this video</p>
                  </div>
                  <Switch id="ai-training-video" defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="visible-connections-video" className="text-blue-100">
                      Visible to Connections
                    </Label>
                    <p className="text-xs text-blue-300">Allow your connections to view this video</p>
                  </div>
                  <Switch id="visible-connections-video" defaultChecked />
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full bg-blue-600 hover:bg-blue-700">Save Video Memory</Button>
            </CardFooter>
          </Card>
        </TabsContent>
        <TabsContent value="document" className="space-y-4">
          <Card className="bg-navy-dark border-blue-900/50">
            <CardHeader>
              <CardTitle className="text-white">Upload Document</CardTitle>
              <CardDescription className="text-blue-300">
                Add important documents to your digital legacy
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="document-title" className="text-blue-100">
                  Document Title
                </Label>
                <Input
                  id="document-title"
                  placeholder="E.g., 'My Life Story' or 'Family Tree'"
                  className="bg-navy-light border-blue-900/50 text-blue-100"
                />
              </div>

              <div className="flex flex-col items-center justify-center space-y-4 p-8 border-2 border-dashed border-blue-900/50 rounded-lg">
                <FileText className="h-10 w-10 text-blue-400" />
                <div className="text-center">
                  <h3 className="text-white font-medium">Drag & Drop Document</h3>
                  <p className="text-sm text-blue-200 mt-1">or click to browse your files</p>
                </div>
                <Button variant="outline" className="border-blue-900/50 text-blue-100">
                  Select Document
                </Button>
                <p className="text-xs text-blue-300">Supported formats: PDF, DOCX, TXT (Max 50MB per file)</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="document-description" className="text-blue-100">
                  Description
                </Label>
                <Textarea
                  id="document-description"
                  placeholder="Describe what this document contains and why it's important..."
                  className="min-h-[150px] bg-navy-light border-blue-900/50 text-blue-100"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="document-category" className="text-blue-100">
                  Category
                </Label>
                <div className="flex items-center space-x-2">
                  <Tag className="h-4 w-4 text-blue-400" />
                  <Select>
                    <SelectTrigger className="bg-navy-light border-blue-900/50 text-blue-100">
                      <SelectValue placeholder="Select a category" />
                    </SelectTrigger>
                    <SelectContent className="bg-navy-dark border-blue-900/50">
                      <SelectItem value="personal">Personal Writing</SelectItem>
                      <SelectItem value="family">Family History</SelectItem>
                      <SelectItem value="legal">Legal Documents</SelectItem>
                      <SelectItem value="creative">Creative Works</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light space-y-3">
                <h3 className="text-sm font-medium text-white">Privacy Settings</h3>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="ai-training-document" className="text-blue-100">
                      Use for AI Training
                    </Label>
                    <p className="text-xs text-blue-300">Allow your AI persona to learn from this document</p>
                  </div>
                  <Switch id="ai-training-document" defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="visible-connections-document" className="text-blue-100">
                      Visible to Connections
                    </Label>
                    <p className="text-xs text-blue-300">Allow your connections to view this document</p>
                  </div>
                  <Switch id="visible-connections-document" defaultChecked />
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full bg-blue-600 hover:bg-blue-700">Save Document</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

