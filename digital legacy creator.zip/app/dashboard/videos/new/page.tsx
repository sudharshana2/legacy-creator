import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Video, Upload, Calendar, Users, Tag } from "lucide-react"
import { Switch } from "@/components/ui/switch"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

export default function CreateVideoPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-white">Create Video Message</h1>
        <p className="text-blue-200">Create an AI-generated video message or upload your own video.</p>
      </div>

      <Tabs defaultValue="ai-video" className="space-y-4">
        <TabsList className="bg-navy-dark border border-blue-900/50">
          <TabsTrigger value="ai-video" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            <Video className="h-4 w-4 mr-2" />
            AI-Generated Video
          </TabsTrigger>
          <TabsTrigger value="upload" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            <Upload className="h-4 w-4 mr-2" />
            Upload Video
          </TabsTrigger>
        </TabsList>
        <TabsContent value="ai-video" className="space-y-4">
          <Card className="bg-navy-dark border-blue-900/50">
            <CardHeader>
              <CardTitle className="text-white">Create AI-Generated Video</CardTitle>
              <CardDescription className="text-blue-300">
                Generate a video message using your AI persona
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="video-title" className="text-blue-100">
                  Video Title
                </Label>
                <Input
                  id="video-title"
                  placeholder="E.g., 'Birthday Message for Emma' or 'Life Advice'"
                  className="bg-navy-light border-blue-900/50 text-blue-100"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="video-script" className="text-blue-100">
                  Video Script
                </Label>
                <Textarea
                  id="video-script"
                  placeholder="Write what you want your AI persona to say in the video..."
                  className="min-h-[200px] bg-navy-light border-blue-900/50 text-blue-100"
                />
                <p className="text-xs text-blue-300">
                  This text will be spoken by your AI persona in the generated video
                </p>
              </div>

              <div className="space-y-2">
                <Label className="text-blue-100">Video Style</Label>
                <RadioGroup defaultValue="casual" className="grid grid-cols-1 md:grid-cols-3 gap-2">
                  <div className="flex items-center space-x-2 rounded-lg border border-blue-900/50 p-3 bg-navy-light">
                    <RadioGroupItem value="casual" id="casual" className="text-blue-400" />
                    <Label htmlFor="casual" className="text-blue-100">
                      Casual
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2 rounded-lg border border-blue-900/50 p-3 bg-navy-light">
                    <RadioGroupItem value="professional" id="professional" className="text-blue-400" />
                    <Label htmlFor="professional" className="text-blue-100">
                      Professional
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2 rounded-lg border border-blue-900/50 p-3 bg-navy-light">
                    <RadioGroupItem value="emotional" id="emotional" className="text-blue-400" />
                    <Label htmlFor="emotional" className="text-blue-100">
                      Emotional
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="space-y-2">
                <Label htmlFor="video-background" className="text-blue-100">
                  Background Setting
                </Label>
                <Select>
                  <SelectTrigger className="bg-navy-light border-blue-900/50 text-blue-100">
                    <SelectValue placeholder="Select a background" />
                  </SelectTrigger>
                  <SelectContent className="bg-navy-dark border-blue-900/50">
                    <SelectItem value="neutral">Neutral Office</SelectItem>
                    <SelectItem value="living-room">Living Room</SelectItem>
                    <SelectItem value="outdoors">Outdoors/Nature</SelectItem>
                    <SelectItem value="gradient">Gradient Background</SelectItem>
                    <SelectItem value="custom">Custom (Upload Image)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="video-duration" className="text-blue-100">
                  Estimated Duration
                </Label>
                <div className="rounded-lg border border-blue-900/50 p-3 bg-navy-light text-blue-100">
                  Approximately 1:45 (based on script length)
                </div>
                <p className="text-xs text-blue-300">Video duration is calculated based on the length of your script</p>
              </div>

              <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light space-y-3">
                <h3 className="text-sm font-medium text-white">Advanced Options</h3>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="emotional-tone" className="text-blue-100">
                      Emotional Tone Matching
                    </Label>
                    <p className="text-xs text-blue-300">Match emotional tone to script content</p>
                  </div>
                  <Switch id="emotional-tone" defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="hand-gestures" className="text-blue-100">
                      Natural Hand Gestures
                    </Label>
                    <p className="text-xs text-blue-300">Include natural hand movements</p>
                  </div>
                  <Switch id="hand-gestures" defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="hd-quality" className="text-blue-100">
                      HD Quality
                    </Label>
                    <p className="text-xs text-blue-300">Generate in high definition (uses more credits)</p>
                  </div>
                  <Switch id="hd-quality" />
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col space-y-2">
              <Button className="w-full bg-blue-600 hover:bg-blue-700">Generate Video</Button>
              <Button variant="outline" className="w-full border-blue-900/50 text-blue-100">
                Preview Script
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        <TabsContent value="upload" className="space-y-4">
          <Card className="bg-navy-dark border-blue-900/50">
            <CardHeader>
              <CardTitle className="text-white">Upload Video</CardTitle>
              <CardDescription className="text-blue-300">
                Upload an existing video to your digital legacy
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="upload-title" className="text-blue-100">
                  Video Title
                </Label>
                <Input
                  id="upload-title"
                  placeholder="E.g., 'Family Vacation' or 'Birthday Message'"
                  className="bg-navy-light border-blue-900/50 text-blue-100"
                />
              </div>

              <div className="flex flex-col items-center justify-center space-y-4 p-8 border-2 border-dashed border-blue-900/50 rounded-lg">
                <Video className="h-10 w-10 text-blue-400" />
                <div className="text-center">
                  <h3 className="text-white font-medium">Drag & Drop Video</h3>
                  <p className="text-sm text-blue-200 mt-1">or click to browse your files</p>
                </div>
                <Button variant="outline" className="border-blue-900/50 text-blue-100">
                  Select Video
                </Button>
                <p className="text-xs text-blue-300">Supported formats: MP4, MOV, AVI (Max 500MB)</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="upload-date" className="text-blue-100">
                    Date Recorded (Optional)
                  </Label>
                  <div className="flex items-center space-x-2">
                    <Calendar className="h-4 w-4 text-blue-400" />
                    <Input id="upload-date" type="date" className="bg-navy-light border-blue-900/50 text-blue-100" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="upload-category" className="text-blue-100">
                    Category
                  </Label>
                  <div className="flex items-center space-x-2">
                    <Tag className="h-4 w-4 text-blue-400" />
                    <Select>
                      <SelectTrigger className="bg-navy-light border-blue-900/50 text-blue-100">
                        <SelectValue placeholder="Select a category" />
                      </SelectTrigger>
                      <SelectContent className="bg-navy-dark border-blue-900/50">
                        <SelectItem value="personal">Personal Message</SelectItem>
                        <SelectItem value="family">Family Event</SelectItem>
                        <SelectItem value="travel">Travel</SelectItem>
                        <SelectItem value="milestone">Life Milestone</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="upload-description" className="text-blue-100">
                  Description
                </Label>
                <Textarea
                  id="upload-description"
                  placeholder="Describe what this video contains and why it's important..."
                  className="min-h-[150px] bg-navy-light border-blue-900/50 text-blue-100"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="upload-people" className="text-blue-100">
                  People in Video (Optional)
                </Label>
                <div className="flex items-center space-x-2">
                  <Users className="h-4 w-4 text-blue-400" />
                  <Input
                    id="upload-people"
                    placeholder="E.g., 'Emma, Michael, Mom, Dad'"
                    className="bg-navy-light border-blue-900/50 text-blue-100"
                  />
                </div>
              </div>

              <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light space-y-3">
                <h3 className="text-sm font-medium text-white">Privacy Settings</h3>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="ai-training-upload" className="text-blue-100">
                      Use for AI Training
                    </Label>
                    <p className="text-xs text-blue-300">Allow your AI persona to learn from this video</p>
                  </div>
                  <Switch id="ai-training-upload" defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="visible-connections-upload" className="text-blue-100">
                      Visible to Connections
                    </Label>
                    <p className="text-xs text-blue-300">Allow your connections to view this video</p>
                  </div>
                  <Switch id="visible-connections-upload" defaultChecked />
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full bg-blue-600 hover:bg-blue-700">Upload Video</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

