import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Video, Plus, Search, Play } from "lucide-react"
import Link from "next/link"
import { Input } from "@/components/ui/input"

export default function VideosPage() {
  const videos = [
    {
      id: "1",
      title: "Life Advice for My Children",
      duration: "3:45",
      date: "Created on May 10, 2023",
      description: "General advice about life, career, and happiness for my children.",
      thumbnail: "/placeholder.svg?height=200&width=300",
    },
    {
      id: "2",
      title: "Family History Stories",
      duration: "5:20",
      date: "Created on June 15, 2023",
      description: "Stories about our family history and ancestry for future generations.",
      thumbnail: "/placeholder.svg?height=200&width=300",
    },
    {
      id: "3",
      title: "Wedding Anniversary Message",
      duration: "2:15",
      date: "Scheduled for July 8, 2025",
      description: "A special message for our 15th wedding anniversary.",
      thumbnail: "/placeholder.svg?height=200&width=300",
    },
    {
      id: "4",
      title: "Birthday Wishes for Emma",
      duration: "1:50",
      date: "Scheduled for May 15, 2026",
      description: "Birthday wishes for my daughter's 18th birthday.",
      thumbnail: "/placeholder.svg?height=200&width=300",
    },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-white">Video Messages</h1>
          <p className="text-blue-200">Create and manage AI-generated video messages for your loved ones.</p>
        </div>
        <Button className="bg-blue-600 hover:bg-blue-700" asChild>
          <Link href="/dashboard/videos/new">
            <Plus className="mr-2 h-4 w-4" /> Create Video
          </Link>
        </Button>
      </div>

      <div className="flex items-center space-x-2">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-blue-400" />
          <Input placeholder="Search videos..." className="pl-8 bg-navy-dark border-blue-900/50 text-blue-100" />
        </div>
        <Button variant="outline" className="border-blue-900/50 text-blue-100">
          Filter
        </Button>
      </div>

      <Tabs defaultValue="all" className="space-y-4">
        <TabsList className="bg-navy-dark border border-blue-900/50">
          <TabsTrigger value="all" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            All Videos
          </TabsTrigger>
          <TabsTrigger value="created" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            Created
          </TabsTrigger>
          <TabsTrigger value="scheduled" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            Scheduled
          </TabsTrigger>
        </TabsList>
        <TabsContent value="all" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {videos.map((video) => (
              <Card key={video.id} className="overflow-hidden bg-navy-dark border-blue-900/50">
                <div className="aspect-video bg-navy-light relative">
                  <img
                    src={video.thumbnail || "/placeholder.svg"}
                    alt={video.title}
                    className="w-full h-full object-cover opacity-60"
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Button size="icon" className="rounded-full w-10 h-10 bg-blue-600 hover:bg-blue-700">
                      <Play className="h-5 w-5" />
                    </Button>
                  </div>
                  <div className="absolute bottom-2 right-2 bg-black/70 px-2 py-1 rounded text-xs text-white">
                    {video.duration}
                  </div>
                </div>
                <CardHeader>
                  <CardTitle className="text-white">{video.title}</CardTitle>
                  <CardDescription className="text-blue-300">{video.date}</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-blue-200">{video.description}</p>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="outline" size="sm" className="border-blue-900/50 text-blue-100">
                    Edit
                  </Button>
                  <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                    Watch
                  </Button>
                </CardFooter>
              </Card>
            ))}
            <Card className="border-dashed border-2 flex flex-col items-center justify-center p-6 h-full bg-transparent border-blue-900/50">
              <Video className="h-10 w-10 text-blue-400 mb-2" />
              <p className="text-blue-200 text-center mb-4">Create a new video message</p>
              <Button className="bg-blue-600 hover:bg-blue-700" asChild>
                <Link href="/dashboard/videos/new">Create Video</Link>
              </Button>
            </Card>
          </div>
        </TabsContent>
        <TabsContent value="created" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {videos
              .filter((v) => v.date.includes("Created"))
              .map((video) => (
                <Card key={video.id} className="overflow-hidden bg-navy-dark border-blue-900/50">
                  <div className="aspect-video bg-navy-light relative">
                    <img
                      src={video.thumbnail || "/placeholder.svg"}
                      alt={video.title}
                      className="w-full h-full object-cover opacity-60"
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Button size="icon" className="rounded-full w-10 h-10 bg-blue-600 hover:bg-blue-700">
                        <Play className="h-5 w-5" />
                      </Button>
                    </div>
                    <div className="absolute bottom-2 right-2 bg-black/70 px-2 py-1 rounded text-xs text-white">
                      {video.duration}
                    </div>
                  </div>
                  <CardHeader>
                    <CardTitle className="text-white">{video.title}</CardTitle>
                    <CardDescription className="text-blue-300">{video.date}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-blue-200">{video.description}</p>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" size="sm" className="border-blue-900/50 text-blue-100">
                      Edit
                    </Button>
                    <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                      Watch
                    </Button>
                  </CardFooter>
                </Card>
              ))}
          </div>
        </TabsContent>
        <TabsContent value="scheduled" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {videos
              .filter((v) => v.date.includes("Scheduled"))
              .map((video) => (
                <Card key={video.id} className="overflow-hidden bg-navy-dark border-blue-900/50">
                  <div className="aspect-video bg-navy-light relative">
                    <img
                      src={video.thumbnail || "/placeholder.svg"}
                      alt={video.title}
                      className="w-full h-full object-cover opacity-60"
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Button size="icon" className="rounded-full w-10 h-10 bg-blue-600 hover:bg-blue-700">
                        <Play className="h-5 w-5" />
                      </Button>
                    </div>
                    <div className="absolute bottom-2 right-2 bg-black/70 px-2 py-1 rounded text-xs text-white">
                      {video.duration}
                    </div>
                  </div>
                  <CardHeader>
                    <CardTitle className="text-white">{video.title}</CardTitle>
                    <CardDescription className="text-blue-300">{video.date}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-blue-200">{video.description}</p>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" size="sm" className="border-blue-900/50 text-blue-100">
                      Edit
                    </Button>
                    <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                      Watch
                    </Button>
                  </CardFooter>
                </Card>
              ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

