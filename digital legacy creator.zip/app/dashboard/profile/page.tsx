import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { User, Mail, Phone, MapPin, Calendar, Shield, Key, CreditCard, Upload } from "lucide-react"
import { Switch } from "@/components/ui/switch"

export default function ProfilePage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-white">My Profile</h1>
        <p className="text-blue-200">Manage your account information and preferences.</p>
      </div>

      <div className="grid gap-6 md:grid-cols-[1fr_3fr]">
        <Card className="bg-navy-dark border-blue-900/50">
          <CardContent className="p-6 flex flex-col items-center space-y-4">
            <Avatar className="h-24 w-24">
              <AvatarImage src="/placeholder.svg?height=96&width=96" alt="Profile" />
              <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-500 text-white text-2xl">
                JD
              </AvatarFallback>
            </Avatar>
            <div className="text-center">
              <h2 className="text-xl font-bold text-white">John Doe</h2>
              <p className="text-blue-200">john.doe@example.com</p>
            </div>
            <Button variant="outline" className="w-full border-blue-900/50 text-blue-100">
              <Upload className="h-4 w-4 mr-2" /> Change Photo
            </Button>
            <div className="w-full pt-4 border-t border-blue-900/50 mt-2">
              <nav className="space-y-1">
                <Button
                  variant="ghost"
                  className="w-full justify-start text-blue-100 hover:bg-blue-900/30 hover:text-blue-100"
                >
                  <User className="h-4 w-4 mr-2 text-blue-400" /> Personal Info
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start text-blue-100 hover:bg-blue-900/30 hover:text-blue-100"
                >
                  <Shield className="h-4 w-4 mr-2 text-blue-400" /> Security
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start text-blue-100 hover:bg-blue-900/30 hover:text-blue-100"
                >
                  <CreditCard className="h-4 w-4 mr-2 text-blue-400" /> Billing
                </Button>
              </nav>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Tabs defaultValue="personal" className="space-y-4">
            <TabsList className="bg-navy-dark border border-blue-900/50">
              <TabsTrigger value="personal" className="data-[state=active]:bg-blue-900/30 text-blue-100">
                Personal Info
              </TabsTrigger>
              <TabsTrigger value="security" className="data-[state=active]:bg-blue-900/30 text-blue-100">
                Security
              </TabsTrigger>
              <TabsTrigger value="billing" className="data-[state=active]:bg-blue-900/30 text-blue-100">
                Billing
              </TabsTrigger>
            </TabsList>
            <TabsContent value="personal" className="space-y-4">
              <Card className="bg-navy-dark border-blue-900/50">
                <CardHeader>
                  <CardTitle className="text-white">Personal Information</CardTitle>
                  <CardDescription className="text-blue-300">Update your personal details</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="first-name" className="text-blue-100">
                        First Name
                      </Label>
                      <Input
                        id="first-name"
                        defaultValue="John"
                        className="bg-navy-light border-blue-900/50 text-blue-100"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="last-name" className="text-blue-100">
                        Last Name
                      </Label>
                      <Input
                        id="last-name"
                        defaultValue="Doe"
                        className="bg-navy-light border-blue-900/50 text-blue-100"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-blue-100">
                      Email Address
                    </Label>
                    <div className="flex items-center space-x-2">
                      <Mail className="h-4 w-4 text-blue-400" />
                      <Input
                        id="email"
                        type="email"
                        defaultValue="john.doe@example.com"
                        className="bg-navy-light border-blue-900/50 text-blue-100"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone" className="text-blue-100">
                      Phone Number
                    </Label>
                    <div className="flex items-center space-x-2">
                      <Phone className="h-4 w-4 text-blue-400" />
                      <Input
                        id="phone"
                        type="tel"
                        defaultValue="+1 (555) 123-4567"
                        className="bg-navy-light border-blue-900/50 text-blue-100"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="birth-date" className="text-blue-100">
                        Date of Birth
                      </Label>
                      <div className="flex items-center space-x-2">
                        <Calendar className="h-4 w-4 text-blue-400" />
                        <Input
                          id="birth-date"
                          type="date"
                          defaultValue="1985-06-15"
                          className="bg-navy-light border-blue-900/50 text-blue-100"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="location" className="text-blue-100">
                        Location
                      </Label>
                      <div className="flex items-center space-x-2">
                        <MapPin className="h-4 w-4 text-blue-400" />
                        <Input
                          id="location"
                          defaultValue="New York, USA"
                          className="bg-navy-light border-blue-900/50 text-blue-100"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="bio" className="text-blue-100">
                      Bio
                    </Label>
                    <Textarea
                      id="bio"
                      placeholder="Tell us a bit about yourself"
                      className="min-h-[100px] bg-navy-light border-blue-900/50 text-blue-100"
                      defaultValue="Digital legacy enthusiast and technology professional with a passion for preserving memories for future generations."
                    />
                    <p className="text-xs text-blue-300">This information will be visible to your connections.</p>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="w-full bg-blue-600 hover:bg-blue-700">Save Changes</Button>
                </CardFooter>
              </Card>

              <Card className="bg-navy-dark border-blue-900/50">
                <CardHeader>
                  <CardTitle className="text-white">Notification Preferences</CardTitle>
                  <CardDescription className="text-blue-300">Manage how we contact you</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label className="text-blue-100">Email Notifications</Label>
                        <p className="text-xs text-blue-300">Receive updates about your account via email</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label className="text-blue-100">SMS Notifications</Label>
                        <p className="text-xs text-blue-300">Receive important alerts via text message</p>
                      </div>
                      <Switch />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label className="text-blue-100">Marketing Communications</Label>
                        <p className="text-xs text-blue-300">Receive news and special offers</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="w-full bg-blue-600 hover:bg-blue-700">Update Preferences</Button>
                </CardFooter>
              </Card>
            </TabsContent>
            <TabsContent value="security" className="space-y-4">
              <Card className="bg-navy-dark border-blue-900/50">
                <CardHeader>
                  <CardTitle className="text-white">Change Password</CardTitle>
                  <CardDescription className="text-blue-300">
                    Update your password to keep your account secure
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="current-password" className="text-blue-100">
                      Current Password
                    </Label>
                    <div className="flex items-center space-x-2">
                      <Key className="h-4 w-4 text-blue-400" />
                      <Input
                        id="current-password"
                        type="password"
                        className="bg-navy-light border-blue-900/50 text-blue-100"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="new-password" className="text-blue-100">
                      New Password
                    </Label>
                    <div className="flex items-center space-x-2">
                      <Key className="h-4 w-4 text-blue-400" />
                      <Input
                        id="new-password"
                        type="password"
                        className="bg-navy-light border-blue-900/50 text-blue-100"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="confirm-password" className="text-blue-100">
                      Confirm New Password
                    </Label>
                    <div className="flex items-center space-x-2">
                      <Key className="h-4 w-4 text-blue-400" />
                      <Input
                        id="confirm-password"
                        type="password"
                        className="bg-navy-light border-blue-900/50 text-blue-100"
                      />
                    </div>
                  </div>

                  <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light">
                    <h3 className="text-sm font-medium text-white mb-2">Password Requirements</h3>
                    <ul className="space-y-1 text-xs text-blue-200">
                      <li>• At least 8 characters long</li>
                      <li>• Include at least one uppercase letter</li>
                      <li>• Include at least one number</li>
                      <li>• Include at least one special character</li>
                    </ul>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="w-full bg-blue-600 hover:bg-blue-700">Update Password</Button>
                </CardFooter>
              </Card>

              <Card className="bg-navy-dark border-blue-900/50">
                <CardHeader>
                  <CardTitle className="text-white">Two-Factor Authentication</CardTitle>
                  <CardDescription className="text-blue-300">
                    Add an extra layer of security to your account
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-blue-100">Enable Two-Factor Authentication</Label>
                      <p className="text-xs text-blue-300">Require a verification code when logging in</p>
                    </div>
                    <Switch defaultChecked />
                  </div>

                  <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light">
                    <h3 className="text-sm font-medium text-white mb-2">Verification Methods</h3>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <input type="radio" id="sms" name="2fa-method" className="text-blue-600" defaultChecked />
                        <Label htmlFor="sms" className="text-blue-100">
                          SMS Text Message
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input type="radio" id="app" name="2fa-method" className="text-blue-600" />
                        <Label htmlFor="app" className="text-blue-100">
                          Authenticator App
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input type="radio" id="email" name="2fa-method" className="text-blue-600" />
                        <Label htmlFor="email" className="text-blue-100">
                          Email
                        </Label>
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="w-full bg-blue-600 hover:bg-blue-700">Save Security Settings</Button>
                </CardFooter>
              </Card>
            </TabsContent>
            <TabsContent value="billing" className="space-y-4">
              <Card className="bg-navy-dark border-blue-900/50">
                <CardHeader>
                  <CardTitle className="text-white">Subscription Plan</CardTitle>
                  <CardDescription className="text-blue-300">
                    Manage your subscription and billing details
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="text-white font-medium">Premium Plan</h3>
                        <p className="text-sm text-blue-200 mt-1">$24.99 per month</p>
                        <ul className="mt-2 space-y-1 text-xs text-blue-300">
                          <li>• Unlimited voice cloning</li>
                          <li>• AI-generated video messages</li>
                          <li>• 50 scheduled future messages</li>
                          <li>• 10GB storage for memories</li>
                        </ul>
                      </div>
                      <div className="bg-blue-900/30 px-2 py-1 rounded text-xs text-blue-100">Current Plan</div>
                    </div>
                    <div className="mt-4 pt-4 border-t border-blue-900/30 flex justify-between items-center">
                      <div className="text-xs text-blue-300">Next billing date: July 15, 2023</div>
                      <Button variant="outline" size="sm" className="border-blue-900/50 text-blue-100">
                        Change Plan
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h3 className="text-sm font-medium text-white">Payment Method</h3>
                    <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light flex justify-between items-center">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-6 bg-white rounded flex items-center justify-center">
                          <span className="text-xs font-bold text-black">VISA</span>
                        </div>
                        <div>
                          <p className="text-sm text-blue-100">•••• •••• •••• 4242</p>
                          <p className="text-xs text-blue-300">Expires 09/2025</p>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm" className="text-blue-100">
                        Edit
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h3 className="text-sm font-medium text-white">Billing Address</h3>
                    <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light">
                      <p className="text-sm text-blue-100">John Doe</p>
                      <p className="text-sm text-blue-100">123 Main Street</p>
                      <p className="text-sm text-blue-100">New York, NY 10001</p>
                      <p className="text-sm text-blue-100">United States</p>
                      <Button variant="ghost" size="sm" className="mt-2 text-blue-100 p-0 h-auto">
                        Edit Address
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h3 className="text-sm font-medium text-white">Billing History</h3>
                    <div className="rounded-lg border border-blue-900/50 overflow-hidden">
                      <div className="bg-navy-light p-3 text-xs font-medium text-blue-100 grid grid-cols-4">
                        <div>Date</div>
                        <div>Description</div>
                        <div>Amount</div>
                        <div className="text-right">Receipt</div>
                      </div>
                      <div className="divide-y divide-blue-900/30">
                        <div className="p-3 text-sm text-blue-200 grid grid-cols-4">
                          <div>Jun 15, 2023</div>
                          <div>Premium Plan</div>
                          <div>$24.99</div>
                          <div className="text-right">
                            <Button variant="link" size="sm" className="h-auto p-0 text-blue-400">
                              Download
                            </Button>
                          </div>
                        </div>
                        <div className="p-3 text-sm text-blue-200 grid grid-cols-4">
                          <div>May 15, 2023</div>
                          <div>Premium Plan</div>
                          <div>$24.99</div>
                          <div className="text-right">
                            <Button variant="link" size="sm" className="h-auto p-0 text-blue-400">
                              Download
                            </Button>
                          </div>
                        </div>
                        <div className="p-3 text-sm text-blue-200 grid grid-cols-4">
                          <div>Apr 15, 2023</div>
                          <div>Premium Plan</div>
                          <div>$24.99</div>
                          <div className="text-right">
                            <Button variant="link" size="sm" className="h-auto p-0 text-blue-400">
                              Download
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}

