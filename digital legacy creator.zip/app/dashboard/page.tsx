import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Brain, Calendar, MessageSquare, Mic, Video, Upload, Plus } from "lucide-react"
import Link from "next/link"

export default function DashboardPage() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-white">Dashboard</h1>
        <p className="text-blue-200">Manage your digital legacy and see how your AI persona is developing.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="bg-navy-dark border-blue-900/50">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-white">AI Training Progress</CardTitle>
            <Brain className="h-4 w-4 text-blue-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">68%</div>
            <Progress value={68} className="mt-2" />
            <p className="text-xs text-blue-200 mt-2">Add more voice recordings to improve your AI persona</p>
          </CardContent>
        </Card>
        <Card className="bg-navy-dark border-blue-900/50">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-white">Voice Samples</CardTitle>
            <Mic className="h-4 w-4 text-blue-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">12 minutes</div>
            <Progress value={40} className="mt-2" />
            <p className="text-xs text-blue-200 mt-2">18 more minutes recommended for optimal voice cloning</p>
          </CardContent>
        </Card>
        <Card className="bg-navy-dark border-blue-900/50">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-white">Scheduled Messages</CardTitle>
            <Calendar className="h-4 w-4 text-blue-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">8</div>
            <p className="text-xs text-blue-200 mt-2">2 messages scheduled for this year</p>
          </CardContent>
        </Card>
        <Card className="bg-navy-dark border-blue-900/50">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-white">Storage Used</CardTitle>
            <Upload className="h-4 w-4 text-blue-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">1.2 GB</div>
            <Progress value={12} className="mt-2" />
            <p className="text-xs text-blue-200 mt-2">8.8 GB available on your plan</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="memories" className="space-y-4">
        <TabsList className="bg-navy-dark border border-blue-900/50">
          <TabsTrigger value="memories" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            Memories
          </TabsTrigger>
          <TabsTrigger value="messages" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            Future Messages
          </TabsTrigger>
          <TabsTrigger value="ai-persona" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            AI Persona
          </TabsTrigger>
        </TabsList>
        <TabsContent value="memories" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card className="overflow-hidden bg-navy-dark border-blue-900/50">
              <div className="aspect-video bg-navy-light relative">
                <img
                  src="/placeholder.svg?height=200&width=300"
                  alt="College Graduation Speech"
                  className="w-full h-full object-cover opacity-60"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <Video className="h-10 w-10 text-blue-400" />
                </div>
              </div>
              <CardHeader>
                <CardTitle className="text-white">College Graduation Speech</CardTitle>
                <CardDescription className="text-blue-300">Added 2 weeks ago</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-blue-200">
                  Your inspirational speech about perseverance and following your dreams.
                </p>
              </CardContent>
            </Card>
            <Card className="overflow-hidden bg-navy-dark border-blue-900/50">
              <div className="aspect-video bg-navy-light relative">
                <img
                  src="/placeholder.svg?height=200&width=300"
                  alt="Life Advice Collection"
                  className="w-full h-full object-cover opacity-60"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <MessageSquare className="h-10 w-10 text-blue-400" />
                </div>
              </div>
              <CardHeader>
                <CardTitle className="text-white">Life Advice Collection</CardTitle>
                <CardDescription className="text-blue-300">Added 1 month ago</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-blue-200">
                  A collection of your best advice on relationships, career, and happiness.
                </p>
              </CardContent>
            </Card>
            <Card className="border-dashed border-2 flex flex-col items-center justify-center p-6 h-full bg-transparent border-blue-900/50">
              <Plus className="h-10 w-10 text-blue-400 mb-2" />
              <p className="text-blue-200 text-center mb-4">Add a new memory</p>
              <Button className="bg-blue-600 hover:bg-blue-700" asChild>
                <Link href="/dashboard/memories/new">Upload Memory</Link>
              </Button>
            </Card>
          </div>
          <Button variant="outline" className="w-full border-blue-900/50 text-blue-100" asChild>
            <Link href="/dashboard/memories">View All Memories</Link>
          </Button>
        </TabsContent>
        <TabsContent value="messages" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card className="bg-navy-dark border-blue-900/50">
              <CardHeader>
                <CardTitle className="text-white">Birthday Message for Emma</CardTitle>
                <CardDescription className="text-blue-300">Scheduled for May 15, 2026</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-blue-200">
                  A special message for your daughter's 18th birthday with advice for adulthood.
                </p>
              </CardContent>
            </Card>
            <Card className="bg-navy-dark border-blue-900/50">
              <CardHeader>
                <CardTitle className="text-white">Wedding Anniversary</CardTitle>
                <CardDescription className="text-blue-300">Scheduled for July 8, 2025</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-blue-200">
                  A loving message for your spouse on your 15th wedding anniversary.
                </p>
              </CardContent>
            </Card>
            <Card className="border-dashed border-2 flex flex-col items-center justify-center p-6 h-full bg-transparent border-blue-900/50">
              <Plus className="h-10 w-10 text-blue-400 mb-2" />
              <p className="text-blue-200 text-center mb-4">Schedule a new message</p>
              <Button className="bg-blue-600 hover:bg-blue-700" asChild>
                <Link href="/dashboard/messages/new">Create Message</Link>
              </Button>
            </Card>
          </div>
          <Button variant="outline" className="w-full border-blue-900/50 text-blue-100" asChild>
            <Link href="/dashboard/messages">View All Messages</Link>
          </Button>
        </TabsContent>
        <TabsContent value="ai-persona" className="space-y-4">
          <Card className="bg-navy-dark border-blue-900/50">
            <CardHeader>
              <CardTitle className="text-white">Your AI Persona</CardTitle>
              <CardDescription className="text-blue-300">
                Train and test your AI-powered digital persona
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <h4 className="text-sm font-medium text-white">Training Status</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center space-x-2">
                    <Brain className="h-4 w-4 text-green-500" />
                    <span className="text-sm text-blue-100">Personality: 85%</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Mic className="h-4 w-4 text-amber-500" />
                    <span className="text-sm text-blue-100">Voice: 40%</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <MessageSquare className="h-4 w-4 text-green-500" />
                    <span className="text-sm text-blue-100">Memories: 72%</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Video className="h-4 w-4 text-red-500" />
                    <span className="text-sm text-blue-100">Video: 15%</span>
                  </div>
                </div>
              </div>
              <div className="pt-4 flex flex-col sm:flex-row gap-2">
                <Button className="bg-blue-600 hover:bg-blue-700" asChild>
                  <Link href="/dashboard/ai-persona/train">Train AI</Link>
                </Button>
                <Button variant="outline" className="border-blue-900/50 text-blue-100" asChild>
                  <Link href="/dashboard/ai-persona/test">Test AI Persona</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

