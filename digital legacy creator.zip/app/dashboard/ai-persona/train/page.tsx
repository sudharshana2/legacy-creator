import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Brain, Mic, MessageSquare, Upload, Video } from "lucide-react"

export default function TrainAIPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Train Your AI Persona</h1>
        <p className="text-muted-foreground">
          Enhance your digital legacy by training your AI persona with your voice, memories, and personality.
        </p>
      </div>

      <Tabs defaultValue="personality" className="space-y-4">
        <TabsList className="grid grid-cols-4 gap-4">
          <TabsTrigger value="personality" className="flex items-center gap-2">
            <Brain className="h-4 w-4" />
            <span>Personality</span>
          </TabsTrigger>
          <TabsTrigger value="voice" className="flex items-center gap-2">
            <Mic className="h-4 w-4" />
            <span>Voice</span>
          </TabsTrigger>
          <TabsTrigger value="memories" className="flex items-center gap-2">
            <MessageSquare className="h-4 w-4" />
            <span>Memories</span>
          </TabsTrigger>
          <TabsTrigger value="video" className="flex items-center gap-2">
            <Video className="h-4 w-4" />
            <span>Video</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="personality" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Personality Training</CardTitle>
              <CardDescription>
                Help your AI understand your communication style, values, and personality traits.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="writing-sample">Writing Sample</Label>
                <Textarea
                  id="writing-sample"
                  placeholder="Share a personal story, opinion, or reflection in your natural writing style..."
                  className="min-h-[200px]"
                />
                <p className="text-xs text-muted-foreground">
                  This helps your AI learn your writing style and thought patterns.
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="values">Core Values & Beliefs</Label>
                <Textarea
                  id="values"
                  placeholder="What principles guide your life? What do you believe strongly about?"
                  className="min-h-[150px]"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="humor">Sense of Humor</Label>
                  <Input id="humor" placeholder="Describe your sense of humor..." />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="communication">Communication Style</Label>
                  <Input id="communication" placeholder="Direct, thoughtful, detailed, etc." />
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full">Save Personality Data</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="voice" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Voice Training</CardTitle>
              <CardDescription>
                Record your voice to enable your AI to speak with your unique vocal characteristics.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="rounded-lg border p-4 bg-muted/50">
                <h3 className="font-medium mb-2">Voice Recording Guidelines</h3>
                <ul className="space-y-1 text-sm text-muted-foreground">
                  <li>• Find a quiet environment with minimal background noise</li>
                  <li>• Speak naturally at your normal pace and tone</li>
                  <li>• Read the provided script completely</li>
                  <li>• Record at least 5 minutes of audio for basic voice cloning</li>
                </ul>
              </div>

              <div className="space-y-2">
                <Label>Recording Script</Label>
                <div className="rounded-lg border p-4 bg-card">
                  <p className="text-sm">
                    The quick brown fox jumps over the lazy dog. I believe that every person has unique gifts to share
                    with the world. My favorite memory from childhood was when we would visit the lake house in summer.
                    The sunset over the mountains creates the most beautiful palette of colors. I've always thought that
                    kindness is the most important quality in a person.
                  </p>
                </div>
              </div>

              <div className="flex flex-col items-center justify-center space-y-4 p-6 border rounded-lg">
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
                  <Mic className="h-8 w-8 text-primary" />
                </div>
                <Button>Start Recording</Button>
                <p className="text-xs text-muted-foreground text-center">
                  Click to start recording. You'll need to grant microphone permissions.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="memories" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Memory Training</CardTitle>
              <CardDescription>
                Share important memories, stories, and life experiences to enrich your AI persona.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="life-story">Life Story</Label>
                <Textarea
                  id="life-story"
                  placeholder="Share significant events, milestones, and experiences from your life..."
                  className="min-h-[200px]"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="memory-title">Memory Title</Label>
                  <Input id="memory-title" placeholder="E.g., 'My Wedding Day'" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="memory-date">When did this happen?</Label>
                  <Input id="memory-date" type="date" />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="memory-details">Memory Details</Label>
                <Textarea
                  id="memory-details"
                  placeholder="Describe this memory in detail, including how you felt, who was there, and why it's important to you..."
                  className="min-h-[150px]"
                />
              </div>

              <div className="flex items-center justify-center border-2 border-dashed rounded-lg p-6">
                <div className="flex flex-col items-center space-y-2">
                  <Upload className="h-8 w-8 text-muted-foreground" />
                  <p className="text-sm font-medium">Upload Photos</p>
                  <p className="text-xs text-muted-foreground text-center">
                    Drag and drop photos related to this memory, or click to browse
                  </p>
                  <Button variant="outline" size="sm">
                    Select Files
                  </Button>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col space-y-2">
              <Button className="w-full">Save This Memory</Button>
              <Button variant="outline" className="w-full">
                Add Another Memory
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="video" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Video Training</CardTitle>
              <CardDescription>
                Upload video footage to enable AI-generated video messages with your likeness.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="rounded-lg border p-4 bg-muted/50">
                <h3 className="font-medium mb-2">Video Guidelines</h3>
                <ul className="space-y-1 text-sm text-muted-foreground">
                  <li>• Record in good lighting with a neutral background</li>
                  <li>• Face the camera directly and speak clearly</li>
                  <li>• Include various facial expressions and head movements</li>
                  <li>• At least 2-3 minutes of footage is recommended</li>
                  <li>• Higher resolution videos produce better results</li>
                </ul>
              </div>

              <div className="flex items-center justify-center border-2 border-dashed rounded-lg p-8">
                <div className="flex flex-col items-center space-y-4">
                  <Video className="h-12 w-12 text-muted-foreground" />
                  <div className="text-center">
                    <p className="text-sm font-medium">Upload Video Footage</p>
                    <p className="text-xs text-muted-foreground">Drag and drop video files, or click to browse</p>
                  </div>
                  <Button>Select Video Files</Button>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="video-consent">Consent Confirmation</Label>
                <div className="flex items-start space-x-2">
                  <input type="checkbox" id="video-consent" className="mt-1" />
                  <Label htmlFor="video-consent" className="text-sm font-normal">
                    I understand and consent to my likeness being used to create AI-generated videos as part of my
                    digital legacy. I have the rights to all uploaded content.
                  </Label>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full">Process Video Data</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

