import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Brain, Mic, MessageSquare, Video, ArrowRight } from "lucide-react"
import Link from "next/link"

export default function AIPersonaPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-white">AI Persona</h1>
        <p className="text-blue-200">
          Train and manage your AI persona to preserve your voice, personality, and memories.
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="bg-navy-dark border-blue-900/50">
          <CardHeader>
            <CardTitle className="text-white">Training Status</CardTitle>
            <CardDescription className="text-blue-300">Your AI persona is 68% complete</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-blue-100">Personality</span>
                <span className="font-medium text-blue-100">85%</span>
              </div>
              <Progress value={85} className="h-2" />
              <p className="text-xs text-blue-200">
                Your personality training is well-developed. Add more writing samples to improve further.
              </p>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-blue-100">Voice</span>
                <span className="font-medium text-blue-100">40%</span>
              </div>
              <Progress value={40} className="h-2" />
              <p className="text-xs text-blue-200">
                Your voice model needs more training data. Record at least 18 more minutes.
              </p>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-blue-100">Memories</span>
                <span className="font-medium text-blue-100">72%</span>
              </div>
              <Progress value={72} className="h-2" />
              <p className="text-xs text-blue-200">
                Your memory database is growing well. Add more personal stories for better context.
              </p>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-blue-100">Video</span>
                <span className="font-medium text-blue-100">15%</span>
              </div>
              <Progress value={15} className="h-2" />
              <p className="text-xs text-blue-200">
                Your video model needs significant more footage for realistic generation.
              </p>
            </div>
          </CardContent>
          <CardFooter>
            <Button className="w-full bg-blue-600 hover:bg-blue-700" asChild>
              <Link href="/dashboard/ai-persona/train">Continue Training</Link>
            </Button>
          </CardFooter>
        </Card>

        <Card className="bg-navy-dark border-blue-900/50">
          <CardHeader>
            <CardTitle className="text-white">AI Persona Preview</CardTitle>
            <CardDescription className="text-blue-300">See how your AI persona appears to others</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center justify-center space-y-4">
            <div className="relative w-24 h-24 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center">
              <span className="text-3xl font-bold text-white">AI</span>
              <div className="absolute bottom-0 right-0 w-6 h-6 rounded-full bg-green-500 border-2 border-navy-dark"></div>
            </div>
            <div className="text-center">
              <h3 className="text-lg font-medium text-white">Your Digital Twin</h3>
              <p className="text-sm text-blue-200">Based on your training data</p>
            </div>
            <div className="w-full p-4 rounded-lg bg-navy-light border border-blue-900/30">
              <p className="text-blue-100 italic">
                "Hello! I'm your AI persona. I've been trained to speak and respond like you would. I can share your
                stories, advice, and memories with your loved ones."
              </p>
            </div>
          </CardContent>
          <CardFooter>
            <Button className="w-full bg-blue-600 hover:bg-blue-700" asChild>
              <Link href="/dashboard/ai-persona/test">Test Your AI Persona</Link>
            </Button>
          </CardFooter>
        </Card>
      </div>

      <Tabs defaultValue="train" className="space-y-4">
        <TabsList className="bg-navy-dark border border-blue-900/50">
          <TabsTrigger value="train" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            Training Options
          </TabsTrigger>
          <TabsTrigger value="settings" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            Persona Settings
          </TabsTrigger>
        </TabsList>
        <TabsContent value="train" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="bg-navy-dark border-blue-900/50">
              <CardHeader className="pb-2">
                <CardTitle className="text-white flex items-center">
                  <Brain className="mr-2 h-5 w-5 text-blue-400" />
                  Personality
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-blue-200">
                  Train your AI to understand your communication style, values, and personality traits.
                </p>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full border-blue-900/50 text-blue-100" asChild>
                  <Link href="/dashboard/ai-persona/train?tab=personality">
                    Train Personality <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </CardFooter>
            </Card>

            <Card className="bg-navy-dark border-blue-900/50">
              <CardHeader className="pb-2">
                <CardTitle className="text-white flex items-center">
                  <Mic className="mr-2 h-5 w-5 text-blue-400" />
                  Voice
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-blue-200">
                  Record your voice to enable your AI to speak with your unique vocal characteristics.
                </p>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full border-blue-900/50 text-blue-100" asChild>
                  <Link href="/dashboard/ai-persona/train?tab=voice">
                    Train Voice <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </CardFooter>
            </Card>

            <Card className="bg-navy-dark border-blue-900/50">
              <CardHeader className="pb-2">
                <CardTitle className="text-white flex items-center">
                  <MessageSquare className="mr-2 h-5 w-5 text-blue-400" />
                  Memories
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-blue-200">
                  Share important memories, stories, and life experiences to enrich your AI persona.
                </p>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full border-blue-900/50 text-blue-100" asChild>
                  <Link href="/dashboard/ai-persona/train?tab=memories">
                    Train Memories <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </CardFooter>
            </Card>

            <Card className="bg-navy-dark border-blue-900/50">
              <CardHeader className="pb-2">
                <CardTitle className="text-white flex items-center">
                  <Video className="mr-2 h-5 w-5 text-blue-400" />
                  Video
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-blue-200">
                  Upload video footage to enable AI-generated video messages with your likeness.
                </p>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full border-blue-900/50 text-blue-100" asChild>
                  <Link href="/dashboard/ai-persona/train?tab=video">
                    Train Video <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>
        <TabsContent value="settings" className="space-y-4">
          <Card className="bg-navy-dark border-blue-900/50">
            <CardHeader>
              <CardTitle className="text-white">Persona Settings</CardTitle>
              <CardDescription className="text-blue-300">
                Customize how your AI persona behaves and interacts
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <h3 className="text-sm font-medium text-white">Communication Style</h3>
                <div className="grid grid-cols-3 gap-2">
                  <Button variant="outline" className="border-blue-900/50 text-blue-100 bg-blue-900/30">
                    Casual
                  </Button>
                  <Button variant="outline" className="border-blue-900/50 text-blue-100">
                    Balanced
                  </Button>
                  <Button variant="outline" className="border-blue-900/50 text-blue-100">
                    Formal
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="text-sm font-medium text-white">Response Length</h3>
                <div className="grid grid-cols-3 gap-2">
                  <Button variant="outline" className="border-blue-900/50 text-blue-100">
                    Concise
                  </Button>
                  <Button variant="outline" className="border-blue-900/50 text-blue-100 bg-blue-900/30">
                    Moderate
                  </Button>
                  <Button variant="outline" className="border-blue-900/50 text-blue-100">
                    Detailed
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="text-sm font-medium text-white">Emotional Tone</h3>
                <div className="grid grid-cols-3 gap-2">
                  <Button variant="outline" className="border-blue-900/50 text-blue-100">
                    Reserved
                  </Button>
                  <Button variant="outline" className="border-blue-900/50 text-blue-100 bg-blue-900/30">
                    Natural
                  </Button>
                  <Button variant="outline" className="border-blue-900/50 text-blue-100">
                    Expressive
                  </Button>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full bg-blue-600 hover:bg-blue-700">Save Settings</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

