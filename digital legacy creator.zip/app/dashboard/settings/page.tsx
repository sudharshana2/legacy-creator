import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Shield, Lock, Bell, Moon, Globe, Database, CreditCard, Trash2 } from "lucide-react"

export default function SettingsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-white">Settings</h1>
        <p className="text-blue-200">Manage your account settings and preferences.</p>
      </div>

      <Tabs defaultValue="general" className="space-y-4">
        <TabsList className="bg-navy-dark border border-blue-900/50">
          <TabsTrigger value="general" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            General
          </TabsTrigger>
          <TabsTrigger value="privacy" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            Privacy & Security
          </TabsTrigger>
          <TabsTrigger value="notifications" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            Notifications
          </TabsTrigger>
          <TabsTrigger value="appearance" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            Appearance
          </TabsTrigger>
          <TabsTrigger value="data" className="data-[state=active]:bg-blue-900/30 text-blue-100">
            Data Management
          </TabsTrigger>
        </TabsList>
        <TabsContent value="general" className="space-y-4">
          <Card className="bg-navy-dark border-blue-900/50">
            <CardHeader>
              <CardTitle className="text-white">General Settings</CardTitle>
              <CardDescription className="text-blue-300">Manage your basic account settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="language" className="text-blue-100">
                  Language
                </Label>
                <div className="flex items-center space-x-2">
                  <Globe className="h-4 w-4 text-blue-400" />
                  <Select>
                    <SelectTrigger className="bg-navy-light border-blue-900/50 text-blue-100">
                      <SelectValue placeholder="Select language" defaultValue="en">
                        English
                      </SelectValue>
                    </SelectTrigger>
                    <SelectContent className="bg-navy-dark border-blue-900/50">
                      <SelectItem value="en">English</SelectItem>
                      <SelectItem value="es">Español</SelectItem>
                      <SelectItem value="fr">Français</SelectItem>
                      <SelectItem value="de">Deutsch</SelectItem>
                      <SelectItem value="ja">日本語</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="timezone" className="text-blue-100">
                  Time Zone
                </Label>
                <Select>
                  <SelectTrigger className="bg-navy-light border-blue-900/50 text-blue-100">
                    <SelectValue placeholder="Select time zone" defaultValue="america-new_york">
                      Eastern Time (US & Canada)
                    </SelectValue>
                  </SelectTrigger>
                  <SelectContent className="bg-navy-dark border-blue-900/50">
                    <SelectItem value="america-new_york">Eastern Time (US & Canada)</SelectItem>
                    <SelectItem value="america-chicago">Central Time (US & Canada)</SelectItem>
                    <SelectItem value="america-denver">Mountain Time (US & Canada)</SelectItem>
                    <SelectItem value="america-los_angeles">Pacific Time (US & Canada)</SelectItem>
                    <SelectItem value="europe-london">London</SelectItem>
                    <SelectItem value="europe-paris">Paris</SelectItem>
                    <SelectItem value="asia-tokyo">Tokyo</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="date-format" className="text-blue-100">
                  Date Format
                </Label>
                <Select>
                  <SelectTrigger className="bg-navy-light border-blue-900/50 text-blue-100">
                    <SelectValue placeholder="Select date format" defaultValue="mdy">
                      MM/DD/YYYY
                    </SelectValue>
                  </SelectTrigger>
                  <SelectContent className="bg-navy-dark border-blue-900/50">
                    <SelectItem value="mdy">MM/DD/YYYY</SelectItem>
                    <SelectItem value="dmy">DD/MM/YYYY</SelectItem>
                    <SelectItem value="ymd">YYYY/MM/DD</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="email-visible" className="text-blue-100">
                    Email Visibility
                  </Label>
                  <p className="text-xs text-blue-300">Show your email to connections</p>
                </div>
                <Switch id="email-visible" />
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full bg-blue-600 hover:bg-blue-700">Save General Settings</Button>
            </CardFooter>
          </Card>
        </TabsContent>
        <TabsContent value="privacy" className="space-y-4">
          <Card className="bg-navy-dark border-blue-900/50">
            <CardHeader>
              <CardTitle className="text-white">Privacy & Security</CardTitle>
              <CardDescription className="text-blue-300">Manage your privacy and security settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light space-y-3">
                <h3 className="text-sm font-medium text-white flex items-center">
                  <Shield className="h-4 w-4 mr-2 text-blue-400" />
                  Account Security
                </h3>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="two-factor" className="text-blue-100">
                      Two-Factor Authentication
                    </Label>
                    <p className="text-xs text-blue-300">Require a verification code when logging in</p>
                  </div>
                  <Switch id="two-factor" defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="login-alerts" className="text-blue-100">
                      Login Alerts
                    </Label>
                    <p className="text-xs text-blue-300">Get notified of new logins to your account</p>
                  </div>
                  <Switch id="login-alerts" defaultChecked />
                </div>
                <Button variant="outline" size="sm" className="mt-2 border-blue-900/50 text-blue-100">
                  <Lock className="h-4 w-4 mr-2" />
                  Change Password
                </Button>
              </div>

              <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light space-y-3">
                <h3 className="text-sm font-medium text-white">Privacy Controls</h3>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="profile-visibility" className="text-blue-100">
                      Profile Visibility
                    </Label>
                    <p className="text-xs text-blue-300">Who can see your profile</p>
                  </div>
                  <Select>
                    <SelectTrigger className="w-[180px] bg-navy border-blue-900/50 text-blue-100">
                      <SelectValue placeholder="Select visibility" />
                    </SelectTrigger>
                    <SelectContent className="bg-navy-dark border-blue-900/50">
                      <SelectItem value="connections">Connections Only</SelectItem>
                      <SelectItem value="invited">Invited Users</SelectItem>
                      <SelectItem value="public">Public</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="memory-visibility" className="text-blue-100">
                      Memory Visibility
                    </Label>
                    <p className="text-xs text-blue-300">Default privacy for new memories</p>
                  </div>
                  <Select>
                    <SelectTrigger className="w-[180px] bg-navy border-blue-900/50 text-blue-100">
                      <SelectValue placeholder="Select visibility" />
                    </SelectTrigger>
                    <SelectContent className="bg-navy-dark border-blue-900/50">
                      <SelectItem value="private">Private</SelectItem>
                      <SelectItem value="connections">Connections Only</SelectItem>
                      <SelectItem value="specific">Specific People</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light space-y-3">
                <h3 className="text-sm font-medium text-white">Data Usage</h3>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="analytics" className="text-blue-100">
                      Analytics
                    </Label>
                    <p className="text-xs text-blue-300">Allow anonymous usage data collection</p>
                  </div>
                  <Switch id="analytics" />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="personalization" className="text-blue-100">
                      Personalization
                    </Label>
                    <p className="text-xs text-blue-300">Allow data to be used for personalized experiences</p>
                  </div>
                  <Switch id="personalization" defaultChecked />
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full bg-blue-600 hover:bg-blue-700">Save Privacy Settings</Button>
            </CardFooter>
          </Card>
        </TabsContent>
        <TabsContent value="notifications" className="space-y-4">
          <Card className="bg-navy-dark border-blue-900/50">
            <CardHeader>
              <CardTitle className="text-white">Notification Settings</CardTitle>
              <CardDescription className="text-blue-300">Manage how and when you receive notifications</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light space-y-3">
                <h3 className="text-sm font-medium text-white flex items-center">
                  <Bell className="h-4 w-4 mr-2 text-blue-400" />
                  Notification Channels
                </h3>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="email-notifications" className="text-blue-100">
                      Email Notifications
                    </Label>
                    <p className="text-xs text-blue-300">Receive notifications via email</p>
                  </div>
                  <Switch id="email-notifications" defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="push-notifications" className="text-blue-100">
                      Push Notifications
                    </Label>
                    <p className="text-xs text-blue-300">Receive notifications in your browser</p>
                  </div>
                  <Switch id="push-notifications" defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="sms-notifications" className="text-blue-100">
                      SMS Notifications
                    </Label>
                    <p className="text-xs text-blue-300">Receive important alerts via text message</p>
                  </div>
                  <Switch id="sms-notifications" />
                </div>
              </div>

              <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light space-y-3">
                <h3 className="text-sm font-medium text-white">Notification Types</h3>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="connection-requests" className="text-blue-100">
                      Connection Requests
                    </Label>
                    <p className="text-xs text-blue-300">When someone requests to connect with you</p>
                  </div>
                  <Switch id="connection-requests" defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="message-access" className="text-blue-100">
                      Message Access
                    </Label>
                    <p className="text-xs text-blue-300">When someone views your messages</p>
                  </div>
                  <Switch id="message-access" defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="ai-interactions" className="text-blue-100">
                      AI Interactions
                    </Label>
                    <p className="text-xs text-blue-300">When someone interacts with your AI persona</p>
                  </div>
                  <Switch id="ai-interactions" defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="system-updates" className="text-blue-100">
                      System Updates
                    </Label>
                    <p className="text-xs text-blue-300">Important updates about the platform</p>
                  </div>
                  <Switch id="system-updates" defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="marketing" className="text-blue-100">
                      Marketing & Promotions
                    </Label>
                    <p className="text-xs text-blue-300">News, offers, and feature updates</p>
                  </div>
                  <Switch id="marketing" />
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full bg-blue-600 hover:bg-blue-700">Save Notification Settings</Button>
            </CardFooter>
          </Card>
        </TabsContent>
        <TabsContent value="appearance" className="space-y-4">
          <Card className="bg-navy-dark border-blue-900/50">
            <CardHeader>
              <CardTitle className="text-white">Appearance Settings</CardTitle>
              <CardDescription className="text-blue-300">Customize how the application looks</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light space-y-3">
                <h3 className="text-sm font-medium text-white flex items-center">
                  <Moon className="h-4 w-4 mr-2 text-blue-400" />
                  Theme
                </h3>
                <div className="grid grid-cols-3 gap-2">
                  <div className="border border-blue-500 rounded-lg p-3 bg-navy flex flex-col items-center">
                    <div className="w-full h-10 bg-navy-dark rounded mb-2"></div>
                    <span className="text-xs text-blue-100">Dark (Default)</span>
                  </div>
                  <div className="border border-blue-900/50 rounded-lg p-3 bg-navy flex flex-col items-center">
                    <div className="w-full h-10 bg-white rounded mb-2"></div>
                    <span className="text-xs text-blue-100">Light</span>
                  </div>
                  <div className="border border-blue-900/50 rounded-lg p-3 bg-navy flex flex-col items-center">
                    <div className="w-full h-10 bg-gradient-to-r from-navy-dark to-navy-light rounded mb-2"></div>
                    <span className="text-xs text-blue-100">System</span>
                  </div>
                </div>
              </div>

              <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light space-y-3">
                <h3 className="text-sm font-medium text-white">Accent Color</h3>
                <div className="grid grid-cols-4 gap-2">
                  <div className="border border-blue-500 rounded-lg p-2 flex items-center justify-center">
                    <div className="w-6 h-6 rounded-full bg-blue-500"></div>
                  </div>
                  <div className="border border-blue-900/50 rounded-lg p-2 flex items-center justify-center">
                    <div className="w-6 h-6 rounded-full bg-purple-500"></div>
                  </div>
                  <div className="border border-blue-900/50 rounded-lg p-2 flex items-center justify-center">
                    <div className="w-6 h-6 rounded-full bg-green-500"></div>
                  </div>
                  <div className="border border-blue-900/50 rounded-lg p-2 flex items-center justify-center">
                    <div className="w-6 h-6 rounded-full bg-amber-500"></div>
                  </div>
                </div>
              </div>

              <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light space-y-3">
                <h3 className="text-sm font-medium text-white">Font Size</h3>
                <div className="grid grid-cols-3 gap-2">
                  <Button variant="outline" className="border-blue-900/50 text-blue-100">
                    <span className="text-sm">Small</span>
                  </Button>
                  <Button variant="outline" className="border-blue-500 bg-blue-900/30 text-blue-100">
                    <span className="text-base">Medium</span>
                  </Button>
                  <Button variant="outline" className="border-blue-900/50 text-blue-100">
                    <span className="text-lg">Large</span>
                  </Button>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="animations" className="text-blue-100">
                    Interface Animations
                  </Label>
                  <p className="text-xs text-blue-300">Enable animations throughout the interface</p>
                </div>
                <Switch id="animations" defaultChecked />
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full bg-blue-600 hover:bg-blue-700">Save Appearance Settings</Button>
            </CardFooter>
          </Card>
        </TabsContent>
        <TabsContent value="data" className="space-y-4">
          <Card className="bg-navy-dark border-blue-900/50">
            <CardHeader>
              <CardTitle className="text-white">Data Management</CardTitle>
              <CardDescription className="text-blue-300">Manage your data and account information</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light space-y-3">
                <h3 className="text-sm font-medium text-white flex items-center">
                  <Database className="h-4 w-4 mr-2 text-blue-400" />
                  Storage Usage
                </h3>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-blue-100">Used Storage</span>
                    <span className="font-medium text-blue-100">1.2 GB of 10 GB</span>
                  </div>
                  <div className="h-2 w-full bg-navy-dark rounded-full overflow-hidden">
                    <div className="h-full bg-blue-500 rounded-full" style={{ width: "12%" }}></div>
                  </div>
                  <div className="grid grid-cols-4 gap-2 text-xs text-blue-300 text-center">
                    <div>
                      <div className="font-medium text-blue-100">350 MB</div>
                      <div>Text</div>
                    </div>
                    <div>
                      <div className="font-medium text-blue-100">450 MB</div>
                      <div>Images</div>
                    </div>
                    <div>
                      <div className="font-medium text-blue-100">350 MB</div>
                      <div>Videos</div>
                    </div>
                    <div>
                      <div className="font-medium text-blue-100">50 MB</div>
                      <div>Other</div>
                    </div>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="w-full border-blue-900/50 text-blue-100">
                  <CreditCard className="h-4 w-4 mr-2" />
                  Upgrade Storage Plan
                </Button>
              </div>

              <div className="rounded-lg border border-blue-900/50 p-4 bg-navy-light space-y-3">
                <h3 className="text-sm font-medium text-white">Data Export</h3>
                <p className="text-xs text-blue-200">
                  Download a copy of all your data, including memories, messages, and AI training data.
                </p>
                <Button variant="outline" size="sm" className="w-full border-blue-900/50 text-blue-100">
                  Request Data Export
                </Button>
              </div>

              <div className="rounded-lg border border-red-900/30 p-4 bg-red-950/10 space-y-3">
                <h3 className="text-sm font-medium text-red-300 flex items-center">
                  <Trash2 className="h-4 w-4 mr-2 text-red-400" />
                  Danger Zone
                </h3>
                <p className="text-xs text-red-200/70">These actions are permanent and cannot be undone.</p>
                <div className="space-y-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full border-red-900/50 text-red-300 hover:bg-red-950/30 hover:text-red-200"
                  >
                    Delete All Memories
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full border-red-900/50 text-red-300 hover:bg-red-950/30 hover:text-red-200"
                  >
                    Reset AI Persona
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full border-red-900/50 text-red-300 hover:bg-red-950/30 hover:text-red-200"
                  >
                    Delete Account
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

