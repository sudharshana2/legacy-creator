"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Menu, X } from "lucide-react"
import { useMobile } from "@/hooks/use-mobile"

export function Navbar() {
  const isMobile = useMobile()
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <nav className="sticky top-0 z-50 w-full border-b border-blue-900/50 bg-navy-dark/80 backdrop-blur-md">
      <div className="container flex h-16 items-center justify-between">
        <Link href="/" className="flex items-center space-x-2">
          <span className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
            Eternal Echo
          </span>
        </Link>

        {isMobile ? (
          <>
            <Button variant="ghost" size="icon" onClick={() => setIsMenuOpen(!isMenuOpen)} className="text-blue-100">
              {isMenuOpen ? <X /> : <Menu />}
            </Button>
          </>
        ) : (
          <>
            <div className="flex items-center space-x-6">
              <Link href="/features" className="text-blue-200 hover:text-blue-100 transition-colors">
                Features
              </Link>
              <Link href="/about" className="text-blue-200 hover:text-blue-100 transition-colors">
                About
              </Link>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="outline" className="border-blue-900/50 text-blue-100" asChild>
                <Link href="/login">Log in</Link>
              </Button>
              <Button className="bg-blue-600 hover:bg-blue-700" asChild>
                <Link href="/signup">Sign up</Link>
              </Button>
            </div>
          </>
        )}
      </div>
      {isMobile && isMenuOpen && (
        <div className="absolute top-16 left-0 w-full bg-navy-dark border-b border-blue-900/50 p-4 flex flex-col space-y-4">
          <Link href="/features" onClick={() => setIsMenuOpen(false)} className="text-blue-100">
            Features
          </Link>
          <Link href="/about" onClick={() => setIsMenuOpen(false)} className="text-blue-100">
            About
          </Link>
          <div className="flex flex-col space-y-2">
            <Button variant="outline" className="border-blue-900/50 text-blue-100" asChild>
              <Link href="/login">Log in</Link>
            </Button>
            <Button className="bg-blue-600 hover:bg-blue-700" asChild>
              <Link href="/signup">Sign up</Link>
            </Button>
          </div>
        </div>
      )}
    </nav>
  )
}

