import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export function TestimonialsSection() {
  const testimonials = [
    {
      quote:
        "I created a digital legacy for my grandfather. Now his great-grandchildren can hear his voice and learn from his experiences.",
      name: "Sarah Johnson",
      title: "Granddaughter",
      avatar: "SJ",
      image: "/placeholder.svg?height=100&width=100",
    },
    {
      quote:
        "As someone with a terminal illness, this platform gave me peace of mind knowing my children will still be able to hear my advice.",
      name: "Michael Chen",
      title: "Father of two",
      avatar: "MC",
      image: "/placeholder.svg?height=100&width=100",
    },
    {
      quote:
        "The AI voice technology is incredible. It sounds exactly like my mom. Being able to hear her voice again brings me comfort.",
      name: "David Williams",
      title: "Son",
      avatar: "DW",
      image: "/placeholder.svg?height=100&width=100",
    },
  ]

  return (
    <section className="py-20 bg-navy-light" id="testimonials">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <div className="inline-block rounded-lg bg-blue-900/30 px-3 py-1 text-sm text-blue-100">Testimonials</div>
            <h2 className="text-3xl font-bold tracking-tighter md:text-4xl/tight text-white">Stories from Our Users</h2>
            <p className="mx-auto max-w-[700px] text-blue-200 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              Hear how Eternal Echo has helped people preserve memories and connect across generations.
            </p>
          </div>
        </div>
        <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-3 mt-12">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="border-0 shadow-md bg-navy-dark border-blue-900/50">
              <CardHeader className="pb-2">
                <div className="relative h-12">
                  <svg
                    className="absolute text-blue-500/20 h-12 w-12"
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z" />
                    <path d="M15 21c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2h-4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2h.75c0 2.25.25 4-2.75 4v3c0 1 0 1 1 1z" />
                  </svg>
                </div>
              </CardHeader>
              <CardContent className="pb-4">
                <p className="text-blue-100">{testimonial.quote}</p>
              </CardContent>
              <CardFooter>
                <div className="flex items-center space-x-4">
                  <Avatar>
                    <AvatarImage src={testimonial.image} alt={testimonial.name} />
                    <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-500 text-white">
                      {testimonial.avatar}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm font-medium text-white">{testimonial.name}</p>
                    <p className="text-xs text-blue-300">{testimonial.title}</p>
                  </div>
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

