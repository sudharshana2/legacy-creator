import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative py-20 md:py-32 overflow-hidden">
      <div className="absolute inset-0 navy-gradient -z-10" />
      <div
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage: "url('/placeholder.svg?height=1080&width=1920')",
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
          backgroundBlendMode: "overlay",
        }}
      />
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center space-y-4 text-center">
          <div className="space-y-2">
            <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl/none text-white glow-text">
              Your Legacy,{" "}
              <span className="bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
                Forever Alive
              </span>
            </h1>
            <p className="mx-auto max-w-[700px] text-blue-100 md:text-xl">
              Create an interactive digital legacy with AI-powered voice, video, and text.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 min-[400px]:gap-6">
            <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white" asChild>
              <Link href="/signup">
                Get Started <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" className="border-blue-400 text-blue-100 hover:bg-blue-900/30" asChild>
              <Link href="/demo">Watch Demo</Link>
            </Button>
          </div>
        </div>
        <div className="mt-16 flex justify-center">
          <div className="relative w-full max-w-4xl overflow-hidden rounded-lg shadow-xl">
            <div className="aspect-video bg-navy-light flex items-center justify-center border border-blue-900/50">
              <img
                src="/placeholder.svg?height=540&width=960"
                alt="AI Digital Legacy Platform Interface"
                className="absolute inset-0 w-full h-full object-cover opacity-40"
              />
              <div className="relative text-center p-8 bg-navy-dark/80 backdrop-blur-sm rounded-lg shadow-lg max-w-lg border border-blue-900/50">
                <h3 className="text-2xl font-bold mb-4 text-white">Your Digital Legacy</h3>
                <p className="mb-6 text-blue-100">
                  Preserve your voice, personality, and memories with our AI-powered platform.
                </p>
                <div className="flex justify-center space-x-4">
                  <div className="w-12 h-12 rounded-full bg-blue-900/50 flex items-center justify-center">
                    <span className="text-blue-300 font-bold">AI</span>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-blue-900/50 flex items-center justify-center">
                    <span className="text-blue-300 font-bold">ML</span>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-blue-900/50 flex items-center justify-center">
                    <span className="text-blue-300 font-bold">NLP</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

