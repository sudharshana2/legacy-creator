import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Check } from "lucide-react"
import Link from "next/link"

export function PricingSection() {
  const plans = [
    {
      name: "Basic",
      description: "Perfect for individuals starting their digital legacy journey",
      price: "$9.99",
      period: "per month",
      features: [
        "AI Chatbot with your personality",
        "Voice cloning (limited to 30 minutes)",
        "10 scheduled future messages",
        "1GB storage for memories",
        "Email support",
      ],
      popular: false,
      buttonText: "Get Started",
      buttonVariant: "outline" as const,
    },
    {
      name: "Premium",
      description: "Comprehensive legacy creation with advanced AI features",
      price: "$24.99",
      period: "per month",
      features: [
        "Everything in Basic",
        "Unlimited voice cloning",
        "AI-generated video messages",
        "50 scheduled future messages",
        "10GB storage for memories",
        "Priority support",
      ],
      popular: true,
      buttonText: "Get Premium",
      buttonVariant: "default" as const,
    },
    {
      name: "Family",
      description: "Create and connect multiple legacies for your entire family",
      price: "$49.99",
      period: "per month",
      features: [
        "Everything in Premium",
        "Up to 5 family member profiles",
        "Family timeline integration",
        "Unlimited scheduled messages",
        "50GB shared storage",
        "24/7 dedicated support",
        "Blockchain-secured digital will",
      ],
      popular: false,
      buttonText: "Choose Family",
      buttonVariant: "outline" as const,
    },
  ]

  return (
    <section className="py-20" id="pricing">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <div className="inline-block rounded-lg bg-muted px-3 py-1 text-sm">Pricing</div>
            <h2 className="text-3xl font-bold tracking-tighter md:text-4xl/tight">Choose Your Legacy Plan</h2>
            <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              Select the plan that best fits your needs. All plans include a 14-day free trial.
            </p>
          </div>
        </div>
        <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-3 mt-12">
          {plans.map((plan, index) => (
            <Card
              key={index}
              className={`flex flex-col border-0 shadow-md ${
                plan.popular ? "relative shadow-lg ring-2 ring-purple-500" : ""
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-0 right-0 mx-auto w-fit rounded-full bg-gradient-to-r from-purple-600 to-blue-500 px-3 py-1 text-xs font-medium text-white">
                  Most Popular
                </div>
              )}
              <CardHeader>
                <CardTitle>{plan.name}</CardTitle>
                <CardDescription>{plan.description}</CardDescription>
              </CardHeader>
              <CardContent className="flex-1">
                <div className="mb-6">
                  <span className="text-4xl font-bold">{plan.price}</span>
                  <span className="text-muted-foreground"> {plan.period}</span>
                </div>
                <ul className="space-y-2 text-sm">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center">
                      <Check className="mr-2 h-4 w-4 text-green-500" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter>
                <Button variant={plan.buttonVariant} className="w-full" asChild>
                  <Link href="/signup">{plan.buttonText}</Link>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
        <div className="mt-12 text-center">
          <p className="text-muted-foreground">
            Need a custom plan for your organization?{" "}
            <Link href="/contact" className="text-primary underline underline-offset-4">
              Contact us
            </Link>
          </p>
        </div>
      </div>
    </section>
  )
}

