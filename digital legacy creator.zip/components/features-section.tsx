import { Brain, Calendar, MessageSquare, Mic, Video, ShieldCheck } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export function FeaturesSection() {
  const features = [
    {
      icon: <Brain className="h-10 w-10 text-blue-400" />,
      title: "AI-Generated Interactive Persona",
      description: "Train an AI chatbot with your personal data that mimics your speech patterns and personality.",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      icon: <Mic className="h-10 w-10 text-blue-400" />,
      title: "Voice Cloning & AI Speech",
      description: "Record your voice once, and AI can speak new messages in your voice even after you're gone.",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      icon: <MessageSquare className="h-10 w-10 text-blue-400" />,
      title: "Memory Curation System",
      description: "Upload personal stories and life lessons that AI organizes into a timeline based on themes.",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      icon: <Calendar className="h-10 w-10 text-blue-400" />,
      title: "Future Messaging & AI Predictions",
      description: "Schedule messages for future events and let AI predict answers to future questions.",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      icon: <Video className="h-10 w-10 text-blue-400" />,
      title: "Personalized Video Messages",
      description: "Generate videos with deepfake avatars based on your footage for a more personal connection.",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      icon: <ShieldCheck className="h-10 w-10 text-blue-400" />,
      title: "Secure Digital Will",
      description: "Store encrypted last wishes and grant access via blockchain to ensure privacy.",
      image: "/placeholder.svg?height=200&width=300",
    },
  ]

  return (
    <section className="py-20 bg-navy-light" id="features">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <div className="inline-block rounded-lg bg-blue-900/30 px-3 py-1 text-sm text-blue-100">Features</div>
            <h2 className="text-3xl font-bold tracking-tighter md:text-4xl/tight text-white">
              Preserve Your Legacy with Advanced AI
            </h2>
            <p className="mx-auto max-w-[700px] text-blue-200 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              Our platform combines cutting-edge AI technologies to create a digital version of you.
            </p>
          </div>
        </div>
        <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 mt-12">
          {features.map((feature, index) => (
            <Card
              key={index}
              className="border-0 shadow-md hover:shadow-lg transition-shadow bg-navy-dark border-blue-900/50"
            >
              <div className="relative h-40 overflow-hidden rounded-t-lg">
                <img
                  src={feature.image || "/placeholder.svg"}
                  alt={feature.title}
                  className="w-full h-full object-cover opacity-50"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-navy-dark to-transparent"></div>
              </div>
              <CardHeader>
                <div className="mb-2">{feature.icon}</div>
                <CardTitle className="text-white">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base text-blue-200">{feature.description}</CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

