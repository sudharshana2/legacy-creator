import { Check } from "lucide-react"

export function HowItWorksSection() {
  const steps = [
    {
      number: "01",
      title: "Create Your Account",
      description: "Sign up and set up your profile with basic information about yourself.",
      image: "/placeholder.svg?height=200&width=200",
    },
    {
      number: "02",
      title: "Train Your AI Persona",
      description: "Upload text conversations, record voice samples, and share personal stories.",
      image: "/placeholder.svg?height=200&width=200",
    },
    {
      number: "03",
      title: "Organize Your Memories",
      description: "Categorize your memories, schedule future messages, and create a timeline.",
      image: "/placeholder.svg?height=200&width=200",
    },
    {
      number: "04",
      title: "Share With Loved Ones",
      description: "Invite family and friends to connect with your digital legacy.",
      image: "/placeholder.svg?height=200&width=200",
    },
  ]

  return (
    <section className="py-20 bg-navy" id="how-it-works">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <div className="inline-block rounded-lg bg-blue-900/30 px-3 py-1 text-sm text-blue-100">How It Works</div>
            <h2 className="text-3xl font-bold tracking-tighter md:text-4xl/tight text-white">
              Simple Process, Profound Impact
            </h2>
            <p className="mx-auto max-w-[700px] text-blue-200 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              Creating your digital legacy is easier than you think.
            </p>
          </div>
        </div>
        <div className="mx-auto mt-12 grid max-w-5xl grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
          {steps.map((step, index) => (
            <div key={index} className="flex flex-col items-center text-center">
              <div className="relative mb-4">
                <img
                  src={step.image || "/placeholder.svg"}
                  alt={`Step ${step.number}`}
                  className="w-24 h-24 rounded-full object-cover border-2 border-blue-500"
                />
                <div className="absolute -top-2 -right-2 flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-blue-500 to-purple-500 text-white">
                  <span className="text-sm font-bold">{step.number}</span>
                </div>
              </div>
              <div className="mt-4 space-y-2">
                <h3 className="text-xl font-bold text-white">{step.title}</h3>
                <p className="text-blue-200">{step.description}</p>
              </div>
              {index < steps.length - 1 && (
                <div className="hidden lg:block h-0.5 w-full bg-gradient-to-r from-transparent via-blue-900/50 to-transparent mt-8" />
              )}
            </div>
          ))}
        </div>
        <div className="mt-16 flex justify-center">
          <div className="rounded-lg border border-blue-900/50 bg-navy-dark p-8 shadow-lg max-w-3xl">
            <h3 className="text-2xl font-bold mb-4 text-white">What You'll Need</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Check className="h-5 w-5 text-blue-400" />
                  <span className="text-blue-100">Personal photos and videos</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Check className="h-5 w-5 text-blue-400" />
                  <span className="text-blue-100">Voice recordings (5-10 minutes)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Check className="h-5 w-5 text-blue-400" />
                  <span className="text-blue-100">Written stories and memories</span>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Check className="h-5 w-5 text-blue-400" />
                  <span className="text-blue-100">Social media accounts (optional)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Check className="h-5 w-5 text-blue-400" />
                  <span className="text-blue-100">Email conversations (optional)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Check className="h-5 w-5 text-blue-400" />
                  <span className="text-blue-100">List of important life events</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

