import Link from "next/link"
import { Facebook, Instagram, Twitter, Youtube } from "lucide-react"

export function Footer() {
  return (
    <footer className="border-t border-blue-900/50 bg-navy-dark">
      <div className="container px-4 md:px-6 py-12">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
          <div className="space-y-4">
            <Link href="/" className="flex items-center space-x-2">
              <span className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
                Eternal Echo
              </span>
            </Link>
            <p className="text-blue-200">
              Preserving your legacy through AI-powered voice, video, and text for future generations.
            </p>
            <div className="flex space-x-4">
              <Link href="#" className="text-blue-400 hover:text-blue-300">
                <Facebook className="h-5 w-5" />
                <span className="sr-only">Facebook</span>
              </Link>
              <Link href="#" className="text-blue-400 hover:text-blue-300">
                <Twitter className="h-5 w-5" />
                <span className="sr-only">Twitter</span>
              </Link>
              <Link href="#" className="text-blue-400 hover:text-blue-300">
                <Instagram className="h-5 w-5" />
                <span className="sr-only">Instagram</span>
              </Link>
              <Link href="#" className="text-blue-400 hover:text-blue-300">
                <Youtube className="h-5 w-5" />
                <span className="sr-only">YouTube</span>
              </Link>
            </div>
          </div>
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white">Product</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/features" className="text-blue-200 hover:text-blue-100">
                  Features
                </Link>
              </li>
              <li>
                <Link href="/demo" className="text-blue-200 hover:text-blue-100">
                  Demo
                </Link>
              </li>
              <li>
                <Link href="/faq" className="text-blue-200 hover:text-blue-100">
                  FAQ
                </Link>
              </li>
            </ul>
          </div>
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white">Company</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/about" className="text-blue-200 hover:text-blue-100">
                  About
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-blue-200 hover:text-blue-100">
                  Contact
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="text-blue-200 hover:text-blue-100">
                  Privacy
                </Link>
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-12 border-t border-blue-900/50 pt-8 text-center">
          <p className="text-sm text-blue-200">© {new Date().getFullYear()} Eternal Echo. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}

