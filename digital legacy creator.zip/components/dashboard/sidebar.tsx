"use client"

import type React from "react"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Brain, Calendar, Home, MessageSquare, Mic, Settings, Users, Video, UserPlus } from "lucide-react"
import { useMobile } from "@/hooks/use-mobile"
import { useEffect, useState } from "react"

interface SidebarItemProps {
  href: string
  icon: React.ReactNode
  title: string
}

function SidebarItem({ href, icon, title }: SidebarItemProps) {
  const pathname = usePathname()
  const isActive = pathname === href

  return (
    <Link
      href={href}
      className={cn(
        "flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-all hover:text-blue-100",
        isActive ? "bg-blue-900/30 font-medium text-blue-100" : "text-blue-200",
      )}
    >
      {icon}
      {title}
    </Link>
  )
}

export function Sidebar() {
  // Use state to handle client-side rendering
  const [mounted, setMounted] = useState(false)
  const isMobile = useMobile()

  // Only show the sidebar after the component has mounted
  useEffect(() => {
    setMounted(true)
  }, [])

  // Don't render anything on the server or if we're on mobile
  if (!mounted || isMobile) {
    return null
  }

  return (
    <div className="hidden border-r border-blue-900/50 bg-navy-dark md:block">
      <div className="flex h-full max-h-screen flex-col gap-2 p-4">
        <div className="flex-1 py-2">
          <nav className="grid gap-1 px-2">
            <SidebarItem href="/dashboard" icon={<Home className="h-4 w-4 text-blue-400" />} title="Dashboard" />
            <SidebarItem
              href="/dashboard/ai-persona"
              icon={<Brain className="h-4 w-4 text-blue-400" />}
              title="AI Persona"
            />
            <SidebarItem
              href="/dashboard/voice"
              icon={<Mic className="h-4 w-4 text-blue-400" />}
              title="Voice Training"
            />
            <SidebarItem
              href="/dashboard/memories"
              icon={<MessageSquare className="h-4 w-4 text-blue-400" />}
              title="Memories"
            />
            <SidebarItem
              href="/dashboard/messages"
              icon={<Calendar className="h-4 w-4 text-blue-400" />}
              title="Future Messages"
            />
            <SidebarItem
              href="/dashboard/videos"
              icon={<Video className="h-4 w-4 text-blue-400" />}
              title="Video Messages"
            />
            <SidebarItem
              href="/dashboard/connections"
              icon={<Users className="h-4 w-4 text-blue-400" />}
              title="Connections"
            />
            <SidebarItem
              href="/dashboard/connections/invite"
              icon={<UserPlus className="h-4 w-4 text-blue-400" />}
              title="Invite Connections"
            />
          </nav>
        </div>
        <div className="mt-auto">
          <nav className="grid gap-1 px-2">
            <SidebarItem
              href="/dashboard/settings"
              icon={<Settings className="h-4 w-4 text-blue-400" />}
              title="Settings"
            />
          </nav>
        </div>
      </div>
    </div>
  )
}

