"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Menu, X, Bell, Settings, User, UserPlus } from "lucide-react"
import { useMobile } from "@/hooks/use-mobile"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export function Navbar() {
  const isMobile = useMobile()
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <nav className="sticky top-0 z-50 w-full border-b border-blue-900/50 bg-navy-dark/80 backdrop-blur-md">
      <div className="flex h-16 items-center px-4 md:px-6">
        {isMobile && (
          <Button variant="ghost" size="icon" onClick={() => setIsMenuOpen(!isMenuOpen)} className="mr-2 text-blue-100">
            {isMenuOpen ? <X /> : <Menu />}
          </Button>
        )}
        <Link href="/dashboard" className="flex items-center space-x-2">
          <span className="text-xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
            Eternal Echo
          </span>
        </Link>
        <div className="ml-auto flex items-center space-x-2">
          <Button variant="outline" size="sm" className="text-blue-100 border-blue-900/50 mr-2 hidden md:flex" asChild>
            <Link href="/dashboard/connections/invite">
              <UserPlus className="h-4 w-4 mr-2" /> Invite
            </Link>
          </Button>
          <Button variant="ghost" size="icon" className="text-blue-100">
            <Bell className="h-5 w-5" />
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="relative h-9 w-9 rounded-full">
                <Avatar>
                  <AvatarImage src="/placeholder.svg?height=32&width=32" alt="User" />
                  <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-500 text-white">
                    JD
                  </AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="bg-navy-dark border-blue-900/50">
              <DropdownMenuLabel className="text-blue-100">My Account</DropdownMenuLabel>
              <DropdownMenuSeparator className="bg-blue-900/50" />
              <DropdownMenuItem className="text-blue-200 focus:text-blue-100 focus:bg-blue-900/30">
                <User className="mr-2 h-4 w-4 text-blue-400" />
                <span>Profile</span>
              </DropdownMenuItem>
              <DropdownMenuItem className="text-blue-200 focus:text-blue-100 focus:bg-blue-900/30">
                <Settings className="mr-2 h-4 w-4 text-blue-400" />
                <span>Settings</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator className="bg-blue-900/50" />
              <DropdownMenuItem className="text-blue-200 focus:text-blue-100 focus:bg-blue-900/30">
                <span>Log out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
      {isMobile && isMenuOpen && (
        <div className="border-t border-blue-900/50 bg-navy-dark">
          <div className="p-4 space-y-3">
            <Link
              href="/dashboard"
              className="flex items-center gap-3 rounded-lg px-3 py-2 text-sm text-blue-200 hover:text-blue-100"
              onClick={() => setIsMenuOpen(false)}
            >
              Dashboard
            </Link>
            <Link
              href="/dashboard/ai-persona"
              className="flex items-center gap-3 rounded-lg px-3 py-2 text-sm text-blue-200 hover:text-blue-100"
              onClick={() => setIsMenuOpen(false)}
            >
              AI Persona
            </Link>
            <Link
              href="/dashboard/memories"
              className="flex items-center gap-3 rounded-lg px-3 py-2 text-sm text-blue-200 hover:text-blue-100"
              onClick={() => setIsMenuOpen(false)}
            >
              Memories
            </Link>
            <Link
              href="/dashboard/connections"
              className="flex items-center gap-3 rounded-lg px-3 py-2 text-sm text-blue-200 hover:text-blue-100"
              onClick={() => setIsMenuOpen(false)}
            >
              Connections
            </Link>
          </div>
        </div>
      )}
    </nav>
  )
}

