"use client"

import { useState, useEffect } from "react"

export const useMobile = () => {
  // Start with a default value that matches the server rendering
  const [isMobile, setIsMobile] = useState(false)

  // Only update the state on the client side
  useEffect(() => {
    const checkIfMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }

    // Set initial value
    checkIfMobile()

    // Add event listener
    window.addEventListener("resize", checkIfMobile)

    // Clean up
    return () => window.removeEventListener("resize", checkIfMobile)
  }, [])

  return isMobile
}

